const Favourite = require('../models/Favourite');
const Vehicle = require('../models/Vehicle');
exports.list = async (req,res) => {
  try { res.json(await Favourite.find({ user: req.user._id }).populate('car')); }
  catch (e) { res.status(500).json({ message: 'Unable to load favourites.' }); }
};
exports.toggle = async (req,res) => {
  try {
    const car = await Vehicle.findById(req.params.carId).select('_id');
    if (!car) return res.status(404).json({ message: 'Car not found.' });
    const existing = await Favourite.findOne({ user: req.user._id, car: car._id });
    if (existing) { await existing.deleteOne(); return res.json({ favourite: false }); }
    await Favourite.create({ user: req.user._id, car: car._id });
    return res.status(201).json({ favourite: true });
  } catch (e) { res.status(500).json({ message: 'Unable to update favourite.' }); }
};
