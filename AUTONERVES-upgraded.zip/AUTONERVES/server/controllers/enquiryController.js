const Enquiry = require('../models/Enquiry');
const Vehicle = require('../models/Vehicle');
const ActivityLog = require('../models/ActivityLog');
exports.create = async (req, res) => {
  try {
    const { carId, name, email, phone, message } = req.body || {};
    if (!carId || !name?.trim() || !/^\S+@\S+\.\S+$/.test(email || '') || !message?.trim()) return res.status(400).json({ message: 'Car, name, valid email and message are required.' });
    const car = await Vehicle.findById(carId).select('_id showroom');
    if (!car) return res.status(404).json({ message: 'Car not found.' });
    const enquiry = await Enquiry.create({ car: car._id, showroom: car.showroom, customer: req.user?._id || null, name: name.trim(), email: email.trim().toLowerCase(), phone, message: message.trim() });
    await ActivityLog.create({ car: car._id, showroom: car.showroom, eventType: 'enquiry_submitted', user: req.user?._id || null, sessionId: req.user ? null : req.header('x-session-id') || null });
    res.status(201).json({ message: 'Enquiry submitted.', enquiry: { id: enquiry._id, status: enquiry.status } });
  } catch (error) { res.status(500).json({ message: 'Unable to submit enquiry.' }); }
};
exports.mine = async (req, res) => {
  try { const rows = await Enquiry.find({ customer: req.user._id }).sort({ createdAt: -1 }).populate('car','brand model year').populate('showroom','name'); res.json(rows); }
  catch (error) { res.status(500).json({ message: 'Unable to load your enquiries.' }); }
};
exports.list = async (req, res) => {
  try {
    const filter = req.user.role === 'admin' ? {} : { showroom: req.user.showroom };
    const rows = await Enquiry.find(filter).sort({ createdAt: -1 }).populate('car','brand model year').select('-__v');
    res.json(rows);
  } catch (error) { res.status(500).json({ message: 'Unable to load enquiries.' }); }
};
exports.updateStatus = async (req, res) => {
  try {
    if (!['new','contacted','closed'].includes(req.body.status)) return res.status(400).json({ message: 'Invalid enquiry status.' });
    const filter = req.user.role === 'admin' ? { _id: req.params.id } : { _id: req.params.id, showroom: req.user.showroom };
    const item = await Enquiry.findOneAndUpdate(filter, { status: req.body.status }, { new: true });
    if (!item) return res.status(404).json({ message: 'Enquiry not found.' });
    res.json(item);
  } catch (error) { res.status(500).json({ message: 'Unable to update enquiry.' }); }
};
