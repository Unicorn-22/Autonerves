const Comparison = require('../models/Comparison');
const Vehicle = require('../models/Vehicle');
exports.get = async (req,res) => {
  try { const doc = await Comparison.findOne({ user: req.user._id }).populate('cars'); res.json(doc?.cars || []); }
  catch (e) { res.status(500).json({ message: 'Unable to load comparison.' }); }
};
exports.save = async (req,res) => {
  try {
    const ids = Array.isArray(req.body.cars) ? [...new Set(req.body.cars.map(String))].slice(0,2) : [];
    if (ids.length !== (await Vehicle.countDocuments({ _id: { $in: ids } }))) return res.status(400).json({ message: 'One or more vehicles are invalid.' });
    const doc = await Comparison.findOneAndUpdate({ user: req.user._id }, { cars: ids }, { upsert: true, new: true, setDefaultsOnInsert: true }).populate('cars');
    res.json(doc.cars);
  } catch (e) { res.status(500).json({ message: 'Unable to save comparison.' }); }
};
