const ActivityLog = require('../models/ActivityLog');
const Vehicle = require('../models/Vehicle');
const Showroom = require('../models/Showroom');

exports.track = async (req, res) => {
  try {
    if (req.header('x-analytics-consent') !== 'yes') return res.status(204).end();
    const { eventType, carId, showroomId, metadata = {}, sessionId } = req.body || {};
    const allowed = ['car_viewed','car_searched','comparison_added','showroom_viewed'];
    if (!allowed.includes(eventType)) return res.status(400).json({ message: 'Unsupported activity event.' });
    let car = null, showroom = showroomId || null;
    if (carId) {
      car = await Vehicle.findById(carId).select('_id showroom');
      if (!car) return res.status(404).json({ message: 'Car not found.' });
      showroom = car.showroom;
    }
    if (showroom && !await Showroom.exists({ _id: showroom })) return res.status(404).json({ message: 'Showroom not found.' });
    if (car && eventType === 'car_viewed') await Vehicle.updateOne({ _id: car._id }, { $inc: { views: 1 } });
    const doc = await ActivityLog.create({
      eventType, car: car?._id || null, showroom,
      user: req.user?._id || null,
      sessionId: req.user ? null : String(sessionId || req.header('x-session-id') || '').slice(0,128) || null,
      metadata: typeof metadata === 'object' && metadata ? metadata : {}
    });
    res.status(201).json({ id: doc._id, recorded: true });
  } catch (error) { res.status(500).json({ message: 'Unable to record activity.' }); }
};

exports.dashboard = async (req, res) => {
  try {
    const scope = req.user.role === 'admin' ? {} : { showroom: req.user.showroom };
    if (req.user.role !== 'admin' && (!req.user.showroom || !await Showroom.exists({ _id: req.user.showroom }))) return res.status(403).json({ message: 'No showroom is assigned to this account.' });
    const since = new Date(Date.now() - 30 * 86400000);
    const [totals, popular, daily, recent, enquiries, showroomPerformance] = await Promise.all([
      ActivityLog.aggregate([{ $match: scope }, { $group: { _id: '$eventType', count: { $sum: 1 } } }]),
      ActivityLog.aggregate([{ $match: { ...scope, car: { $ne: null }, eventType: 'car_viewed' } }, { $group: { _id: '$car', views: { $sum: 1 } } }, { $sort: { views: -1 } }, { $limit: 8 }, { $lookup: { from: 'vehicles-finder', localField: '_id', foreignField: '_id', as: 'car' } }, { $unwind: '$car' }, { $project: { views: 1, brand: '$car.brand', model: '$car.model', showroom: '$car.showroom' } }]),
      ActivityLog.aggregate([{ $match: { ...scope, createdAt: { $gte: since } } }, { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, count: { $sum: 1 } } }, { $sort: { _id: 1 } }]),
      ActivityLog.find(scope).sort({ createdAt: -1 }).limit(20).populate('car','brand model').populate('showroom','name').select('-metadata'),
      require('../models/Enquiry').countDocuments(req.user.role === 'admin' ? {} : { showroom: req.user.showroom }),
      req.user.role === 'admin' ? ActivityLog.aggregate([{ $match: { showroom: { $ne: null } } }, { $group: { _id: '$showroom', views: { $sum: { $cond: [{ $eq: ['$eventType','car_viewed'] },1,0] } }, searches: { $sum: { $cond: [{ $eq: ['$eventType','car_searched'] },1,0] } }, enquiries: { $sum: { $cond: [{ $eq: ['$eventType','enquiry_submitted'] },1,0] } } } }, { $lookup: { from: 'showrooms', localField: '_id', foreignField: '_id', as: 'showroom' } }, { $unwind: '$showroom' }, { $project: { name: '$showroom.name', views: 1, searches: 1, enquiries: 1 } }, { $sort: { views: -1 } }]) : Promise.resolve([])
    ]);
    const counts = Object.fromEntries(totals.map(x => [x._id, x.count]));
    res.json({ scope: req.user.role === 'admin' ? 'all-showrooms' : String(req.user.showroom), totals: { carViews: counts.car_viewed || 0, searches: counts.car_searched || 0, comparisons: counts.comparison_added || 0, showroomViews: counts.showroom_viewed || 0, enquiries: enquiries }, popularCars: popular, daily, recent, showroomPerformance });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Unable to load dashboard analytics.' }); }
};
