const { validationResult } = require('express-validator');
const Vehicle = require('../models/Vehicle');
const Showroom = require('../models/Showroom');
const ShowroomInventory = require('../models/ShowroomInventory');
const CarVariant = require('../models/CarVariant');

// Helper function to calculate distance between two coordinates (Haversine formula)
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2); 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  const distance = R * c; // Distance in km
  return distance;
}

const escapeRegex = value => String(value).slice(0, 80).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function deg2rad(deg) {
  return deg * (Math.PI/180);
}

// Get all vehicles with pagination
exports.getAllVehicles = async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 10));
    const skip = (page - 1) * limit;
    const { category, brand, model, fuelType, transmission, bodyType, minYear, maxYear, minPrice, maxPrice, minMileage, maxMileage, minSeats, maxSeats, minHp, maxHp, sort } = req.query;

    for (const key of ['minPrice','maxPrice','minYear','maxYear','minMileage','maxMileage','minSeats','maxSeats','minHp','maxHp']) {
      if (req.query[key] !== undefined && req.query[key] !== '' && !Number.isFinite(Number(req.query[key]))) return res.status(400).json({ message: `Invalid ${key} filter.` });
    }
    const filter = {};
    if (category && category !== 'all') {
        switch (category) {
            case 'car':
                filter.type = 'car';
                filter.category = { $ne: 'ev' };
                break;
            case 'bike':
                filter.type = 'bike';
                filter.category = { $ne: 'scooty' };
                break;
            case 'ev':
                filter.category = 'ev';
                break;
            case 'scooty':
                filter.category = 'scooty';
                break;
            default:
                filter.category = category;
                break;
        }
    }

    if (brand) filter.brand = new RegExp(escapeRegex(brand), 'i');
    if (model) filter.model = new RegExp(escapeRegex(model), 'i');
    if (minPrice || maxPrice) filter.price = { ...(minPrice ? { $gte: Number(minPrice) } : {}), ...(maxPrice ? { $lte: Number(maxPrice) } : {}) };
    if (fuelType) filter['specifications.fuelType'] = new RegExp(`^${escapeRegex(fuelType)}$`, 'i');
    if (transmission) filter['specifications.transmission'] = new RegExp(escapeRegex(transmission), 'i');
    if (bodyType) filter.bodyType = new RegExp(escapeRegex(bodyType), 'i');
    if (minYear || maxYear) filter.year = { ...(minYear ? { $gte: Number(minYear) } : {}), ...(maxYear ? { $lte: Number(maxYear) } : {}) };
    if (minMileage || maxMileage) filter['specifications.mileage'] = { $exists: true };
    if (minMileage || maxMileage) filter['specifications.mileageValue'] = { ...(minMileage ? { $gte: Number(minMileage) } : {}), ...(maxMileage ? { $lte: Number(maxMileage) } : {}) };
    if (minSeats || maxSeats) filter['specifications.seatingCapacity'] = { ...(minSeats ? { $gte: Number(minSeats) } : {}), ...(maxSeats ? { $lte: Number(maxSeats) } : {}) };
    if (minHp || maxHp) filter['specifications.horsepower'] = { ...(minHp ? { $gte: Number(minHp) } : {}), ...(maxHp ? { $lte: Number(maxHp) } : {}) };
    const sortOptions = { priceAsc: { price: 1 }, priceDesc: { price: -1 }, latest: { year: -1, createdAt: -1 }, mostViewed: { views: -1 } };
    const vehicles = await Vehicle.find(filter)
      .populate('showroom', 'name address location')
      .sort(sortOptions[sort] || { createdAt: -1 })
      .skip(skip)
      .limit(limit);

    const total = await Vehicle.countDocuments(filter);

    if (req.header('x-analytics-consent') === 'yes' && Object.keys(req.query).some(key => !['page','limit','sort'].includes(key))) {
      const ActivityLog = require('../models/ActivityLog');
      const SearchHistory = require('../models/SearchHistory');
      const sessionId = req.header('x-session-id')?.slice(0,128) || null;
      const events = vehicles.map(item => ({ eventType: 'car_searched', car: item._id, showroom: item.showroom?._id || item.showroom || null, user: req.user?._id || null, sessionId }));
      if (events.length) ActivityLog.insertMany(events, { ordered: false }).catch(() => {});
      SearchHistory.create({ user: req.user?._id || null, sessionId, query: '', filters: req.query, resultCount: vehicles.length }).catch(() => {});
    }
    res.set('Cache-Control', 'no-store');
    res.json({
      vehicles,
      totalPages: Math.ceil(total / limit),
      currentPage: page
    });
  } catch (error) {
    console.error('Error in getAllVehicles:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get vehicle by ID
exports.getVehicleById = async (req, res) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id)
      .populate('showroom');
    
    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }
    
    res.json(vehicle);
  } catch (error) {
    console.error('Error in getVehicleById:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.searchVehicles = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    for (const key of ['minPrice','maxPrice','lat','lng','radius','minYear','maxYear','minMileage','maxMileage','minSeats','maxSeats','minHp','maxHp']) { if (req.query[key] !== undefined && !Number.isFinite(Number(req.query[key]))) return res.status(400).json({ message: `Invalid ${key} filter.` }); }
    if (Object.keys(req.query).length === 0) {
      return exports.getAllVehicles(req, res);
    }

    const {
      type,
      brand,
      model,
      minPrice,
      maxPrice,
      lat,
      lng,
      radius = 50, // Default 50km radius
      query, fuelType, transmission, bodyType, minYear, maxYear, minMileage, maxMileage, minSeats, maxSeats, minHp, maxHp
    } = req.query;

    
    // Build search filter
    const filter = {};
    
    if (type && type !== 'all') filter.type = type;
    if (brand) filter.brand = new RegExp(escapeRegex(brand), 'i');
    if (model) filter.model = new RegExp(escapeRegex(model), 'i');
    if (fuelType) filter['specifications.fuelType'] = new RegExp(`^${escapeRegex(fuelType)}$`, 'i');
    if (transmission) filter['specifications.transmission'] = new RegExp(escapeRegex(transmission), 'i');
    if (bodyType) filter.bodyType = new RegExp(escapeRegex(bodyType), 'i');
    if (minYear || maxYear) filter.year = { ...(minYear ? { $gte: Number(minYear) } : {}), ...(maxYear ? { $lte: Number(maxYear) } : {}) };
    if (minMileage || maxMileage) filter['specifications.mileageValue'] = { ...(minMileage ? { $gte: Number(minMileage) } : {}), ...(maxMileage ? { $lte: Number(maxMileage) } : {}) };
    if (minSeats || maxSeats) filter['specifications.seatingCapacity'] = { ...(minSeats ? { $gte: Number(minSeats) } : {}), ...(maxSeats ? { $lte: Number(maxSeats) } : {}) };
    if (minHp || maxHp) filter['specifications.horsepower'] = { ...(minHp ? { $gte: Number(minHp) } : {}), ...(maxHp ? { $lte: Number(maxHp) } : {}) };
    
    // Price range filter
    if (minPrice !== undefined || maxPrice !== undefined) {
      filter.price = {};
      if (minPrice !== undefined && !isNaN(Number(minPrice))) {
        filter.price.$gte = Number(minPrice);
      }
      if (maxPrice !== undefined && !isNaN(Number(maxPrice))) {
        filter.price.$lte = Number(maxPrice);
      }
      if (Object.keys(filter.price).length === 0) {
        delete filter.price;
      }
    }
    
    // Full-text search
    if (query) {
      filter.$or = [
        { brand: new RegExp(escapeRegex(query), 'i') },
        { model: new RegExp(escapeRegex(query), 'i') },
        { description: new RegExp(escapeRegex(query), 'i') }
      ];
    }
    
    let vehicles;
    
    // Location based search
    if (lat !== undefined && lng !== undefined && Number(radius) > 0) {
      if (Math.abs(Number(lat)) > 90 || Math.abs(Number(lng)) > 180 || Number(radius) > 1000) return res.status(400).json({ message: 'Invalid location or radius.' });
      // Find showrooms within the radius
      const showrooms = await Showroom.find({
        location: {
          $near: {
            $geometry: {
              type: 'Point',
              coordinates: [parseFloat(lng), parseFloat(lat)]
            },
            $maxDistance: parseFloat(radius) * 1000 // Convert km to meters
          }
        }
      }).select('_id');
      
      const showroomIds = showrooms.map(s => s._id);
      
      // Add showroom filter
      filter.showroom = { $in: showroomIds };
      
      // Get vehicles with showroom data
      vehicles = await Vehicle.find(filter)
        .populate({
          path: 'showroom',
          select: 'name address location phone email'
        })
        .limit(50);
      
      // Calculate distance for each vehicle and filter
      const vehiclesWithDistance = [];
      for (const vehicle of vehicles) {
        const vehicleObj = vehicle.toObject();
        const showroomLocation = vehicle.showroom.location.coordinates;
        
        // Calculate distance using Haversine formula
        const userLocation = [parseFloat(lng), parseFloat(lat)];
        const distanceInKm = calculateDistance(
          userLocation[1], userLocation[0],
          showroomLocation[1], showroomLocation[0]
        );
        
        if (distanceInKm <= radius) {
          vehicleObj.distance = distanceInKm;
          vehiclesWithDistance.push(vehicleObj);
        }
      }
      
      // Sort by distance
      vehiclesWithDistance.sort((a, b) => a.distance - b.distance);
      vehicles = vehiclesWithDistance;
    } else {
      // Regular search without location
      vehicles = await Vehicle.find(filter)
        .populate('showroom', 'name address phone email')
        .sort({ createdAt: -1 })
        .limit(50);
    }
    
    res.set('Cache-Control', 'no-store');
    res.json(vehicles);
  } catch (error) {
    console.error('Error in searchVehicles:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get unique brands for a vehicle type
exports.getBrands = async (req, res) => {
  try {
    const { type } = req.query;
    const filter = type && type !== 'all' ? { type } : {};
    const brands = await Vehicle.distinct('brand', filter);
    res.json(brands.sort((a,b) => a.localeCompare(b)));
  } catch (error) {
    res.status(500).json({ message: 'Unable to load brands from the vehicle database.' });
  }
};

exports.getModels = async (req, res) => {
  try {
    const { type, brand } = req.query;
    const filter = {};
    if (type && type !== 'all') filter.type = type;
    if (brand) filter.brand = brand;
    const models = await Vehicle.distinct('model', filter);
    res.json(models.sort((a,b) => a.localeCompare(b)));
  } catch (error) {
    res.status(500).json({ message: 'Unable to load models from the vehicle database.' });
  }
};

// Create new vehicle
exports.createVehicle = async (req, res) => {
  try {
    // Check if user is a dealer
    if (req.user.role !== 'dealer' && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to add vehicles' });
    }
    
    // Check if the showroom belongs to the dealer
    const showroom = await Showroom.findById(req.body.showroom);
    
    if (!showroom) {
      return res.status(404).json({ message: 'Showroom not found' });
    }
    
    if (req.user.role !== 'admin' && (req.user.role !== 'dealer' || String(req.user.showroom || '') !== String(showroom._id))) {
      return res.status(403).json({ message: 'Not authorized to add vehicles to this showroom' });
    }
    
    // Create new vehicle
    if (req.user.role === 'dealer' && (!req.user.showroom || String(req.body.showroom) !== String(req.user.showroom))) return res.status(403).json({ message: 'You can only add vehicles to your assigned showroom.' });
    const hasPriceSource = Boolean(req.body.source && req.body.sourceUpdatedAt);
    const newVehicle = new Vehicle({
      ...req.body,
      isDemo: false,
      priceIsDemo: !hasPriceSource,
      source: hasPriceSource ? req.body.source : 'Not verified - source not supplied'
    });
    
    await newVehicle.save();
    await ShowroomInventory.create({ showroom: newVehicle.showroom, vehicle: newVehicle._id, stock: newVehicle.available ? 1 : 0, status: newVehicle.available ? 'available' : 'inactive', updatedBy: req.user._id });
    if (newVehicle.variant) await CarVariant.create({ vehicle: newVehicle._id, name: newVehicle.variant, year: newVehicle.year, exShowroomPrice: newVehicle.price, specifications: newVehicle.specifications, isDemo: newVehicle.isDemo, priceIsDemo: newVehicle.priceIsDemo, source: newVehicle.source, lastUpdatedAt: new Date() });
    res.status(201).json(newVehicle);
  } catch (error) {
    console.error('Error in createVehicle:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Update vehicle
exports.updateVehicle = async (req, res) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    
    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }
    
    // Get showroom to check ownership
    const showroom = await Showroom.findById(vehicle.showroom);
    
    if (!showroom) {
      return res.status(404).json({ message: 'Showroom not found' });
    }
    
    // Check if user is authorized to update
    if (req.user.role !== 'admin' && (req.user.role !== 'dealer' || String(req.user.showroom || '') !== String(showroom._id))) {
      return res.status(403).json({ message: 'Not authorized to update this vehicle' });
    }
    
    // Update vehicle
    const updatedVehicle = await Vehicle.findByIdAndUpdate(
      req.params.id,
      { $set: {
        ...Object.fromEntries(Object.entries(req.body).filter(([key]) => req.user.role === 'admin' || !['showroom','isDemo','priceIsDemo'].includes(key))),
        ...(Object.keys(req.body).some(key => ['price','source','sourceUpdatedAt'].includes(key))
          ? { priceIsDemo: !(req.body.source && req.body.sourceUpdatedAt), source: req.body.source && req.body.sourceUpdatedAt ? req.body.source : 'Not verified - source not supplied' } : {})
      } },
      { new: true }
    ).populate('showroom');
    
    await ShowroomInventory.findOneAndUpdate(
      { vehicle: updatedVehicle._id },
      { showroom: updatedVehicle.showroom, stock: updatedVehicle.available ? 1 : 0, status: updatedVehicle.available ? 'available' : 'inactive', updatedBy: req.user._id },
      { upsert: true, new: true }
    );
    if (updatedVehicle.variant) await CarVariant.findOneAndUpdate(
      { vehicle: updatedVehicle._id, name: updatedVehicle.variant },
      { year: updatedVehicle.year, exShowroomPrice: updatedVehicle.price, specifications: updatedVehicle.specifications, isDemo: updatedVehicle.isDemo, priceIsDemo: updatedVehicle.priceIsDemo, source: updatedVehicle.source, lastUpdatedAt: new Date() },
      { upsert: true, new: true }
    );
    res.json(updatedVehicle);
  } catch (error) {
    console.error('Error in updateVehicle:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Delete vehicle
exports.deleteVehicle = async (req, res) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    
    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }
    
    // Get showroom to check ownership
    const showroom = await Showroom.findById(vehicle.showroom);
    
    if (!showroom) {
      return res.status(404).json({ message: 'Showroom not found' });
    }
    
    // Check if user is authorized to delete
    if (req.user.role !== 'admin' && (req.user.role !== 'dealer' || String(req.user.showroom || '') !== String(showroom._id))) {
      return res.status(403).json({ message: 'Not authorized to delete this vehicle' });
    }
    
    await Vehicle.findByIdAndRemove(req.params.id);
    await Promise.all([ShowroomInventory.deleteMany({ vehicle: vehicle._id }), CarVariant.deleteMany({ vehicle: vehicle._id })]);
    res.json({ message: 'Vehicle removed' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Upload images for a vehicle
exports.uploadVehicleImages = async (req, res) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);

    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }

    // Check ownership (similar to update/delete logic)
    const showroom = await Showroom.findById(vehicle.showroom);
    if (req.user.role !== 'admin' && (req.user.role !== 'dealer' || String(req.user.showroom || '') !== String(showroom._id))) {
      return res.status(403).json({ message: 'Not authorized to add images to this vehicle' });
    }

    if (req.files) {
      const imagePaths = req.files.map(file => `/uploads/vehicles/${file.filename}`);
      
      vehicle.images = vehicle.images.concat(imagePaths);
      await vehicle.save();

      res.json(vehicle);
    } else {
      res.status(400).json({ message: 'No images uploaded' });
    }
  } catch (error) {
    console.error('Error in uploadVehicleImages:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

