const User = require('../models/User');
const Showroom = require('../models/Showroom');
const Vehicle = require('../models/Vehicle');
const ActivityLog = require('../models/ActivityLog');
const Enquiry = require('../models/Enquiry');

const getUsers = async (req, res) => {
  try { res.json(await User.find({}).select('-password')); }
  catch (error) { res.status(500).json({ message: 'Unable to load users.' }); }
};
const getShowrooms = async (req, res) => {
  try { res.json(await Showroom.find({}).populate('owner', 'name email')); }
  catch (error) { res.status(500).json({ message: 'Unable to load showrooms.' }); }
};
const createShowroomAdmin = async (req, res) => {
  try {
    const { name, email, password, showroomId, phone } = req.body || {};
    if (!name?.trim() || !/^\S+@\S+\.\S+$/.test(email || '') || !password || password.length < 8 || !showroomId)
      return res.status(400).json({ message: 'Name, valid email, password (8+ chars) and showroom are required.' });
    const showroom = await Showroom.findById(showroomId);
    if (!showroom) return res.status(404).json({ message: 'Showroom not found.' });
    if (await User.exists({ email: email.toLowerCase() })) return res.status(409).json({ message: 'Email already registered.' });
    await User.updateMany({ role: 'dealer', showroom: showroom._id }, { isActive: false, showroom: null });
    const user = await User.create({ name: name.trim(), email: email.toLowerCase(), password, phone, role: 'dealer', showroom: showroom._id, isActive: true });
    showroom.owner = user._id;
    await showroom.save();
    res.status(201).json({ id: user._id, name: user.name, email: user.email, role: user.role, showroom: showroom._id });
  } catch (error) { res.status(500).json({ message: 'Unable to create showroom admin.' }); }
};
const updateUserStatus = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { isActive: req.body.isActive === true }, { new: true }).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found.' });
    res.json(user);
  } catch (error) { res.status(500).json({ message: 'Unable to update user status.' }); }
};
const getDashboardSummary = async (req, res) => {
  try {
    const [customers, showrooms, cars, views, searches, enquiries, popularBrands] = await Promise.all([
      User.countDocuments({ role: 'buyer' }), Showroom.countDocuments({ isActive: { $ne: false } }),
      Vehicle.countDocuments({ type: 'car' }), ActivityLog.countDocuments({ eventType: 'car_viewed' }),
      ActivityLog.countDocuments({ eventType: 'car_searched' }), Enquiry.countDocuments(),
      Vehicle.aggregate([{ $match: { type: 'car' } }, { $group: { _id: '$brand', count: { $sum: 1 } } }, { $sort: { count: -1 } }, { $limit: 8 }])
    ]);
    res.json({ customers, showrooms, cars, views, searches, enquiries, popularBrands });
  } catch (error) { res.status(500).json({ message: 'Unable to load dashboard summary.' }); }
};
module.exports = { getUsers, getShowrooms, createShowroomAdmin, updateUserStatus, getDashboardSummary };
