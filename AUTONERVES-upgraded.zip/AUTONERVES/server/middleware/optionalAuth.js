const jwt = require('jsonwebtoken');
const User = require('../models/User');
module.exports = async (req, res, next) => {
  const token = req.header('x-auth-token');
  if (token && process.env.JWT_SECRET) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findOne({ _id: decoded.user.id, isActive: { $ne: false } }).select('-password');
    } catch (_) { /* Public browsing remains available for expired/invalid optional tokens. */ }
  }
  next();
};
