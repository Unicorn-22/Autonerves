const router = require('express').Router();
const protect = require('../middleware/auth');
const optionalAuth = require('../middleware/optionalAuth');
const activity = require('../controllers/activityController');
router.post('/track', optionalAuth, activity.track);
router.get('/dashboard', protect, activity.dashboard);
module.exports = router;
