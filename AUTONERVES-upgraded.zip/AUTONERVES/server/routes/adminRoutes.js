const express = require('express');
const router = express.Router();
const { getUsers, getShowrooms, createShowroomAdmin, getDashboardSummary, updateUserStatus } = require('../controllers/adminController');
const protect = require('../middleware/auth');
const admin = require('../middleware/admin');

router.get('/dashboard', protect, admin, getDashboardSummary);
router.post('/showroom-admins', protect, admin, createShowroomAdmin);
router.patch('/users/:id/status', protect, admin, updateUserStatus);

// @route   GET /api/admin/users
router.get('/users', protect, admin, getUsers);

// @route   GET /api/admin/showrooms
router.get('/showrooms', protect, admin, getShowrooms);

module.exports = router;