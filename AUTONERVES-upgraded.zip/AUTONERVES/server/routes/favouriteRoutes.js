const router = require('express').Router();
const protect = require('../middleware/auth');
const controller = require('../controllers/favouriteController');
router.use(protect);
router.get('/', controller.list);
router.post('/:carId/toggle', controller.toggle);
module.exports = router;
