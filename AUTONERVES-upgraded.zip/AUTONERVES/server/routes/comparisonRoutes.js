const router = require('express').Router();
const protect = require('../middleware/auth');
const controller = require('../controllers/comparisonController');
router.use(protect);
router.get('/', controller.get);
router.put('/', controller.save);
module.exports = router;
