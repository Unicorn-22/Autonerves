const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  showroom: { type: mongoose.Schema.Types.ObjectId, ref: 'Showroom', required: true, index: true },
  vehicle: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle', required: true, index: true },
  variant: { type: mongoose.Schema.Types.ObjectId, ref: 'CarVariant', default: null },
  stock: { type: Number, min: 0, default: 0 },
  status: { type: String, enum: ['available','reserved','sold','inactive'], default: 'available' },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });
schema.index({ showroom: 1, vehicle: 1, variant: 1 }, { unique: true });
module.exports = mongoose.model('ShowroomInventory', schema);
