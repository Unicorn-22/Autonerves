const mongoose = require('mongoose');

const showroomSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  showroomCode: { type: String, unique: true, sparse: true, trim: true },
  isActive: { type: Boolean, default: true },
  isDemo: { type: Boolean, default: true },
  postalCode: { type: String, default: '' },
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  address: {
    type: String,
    required: true
  },
  city: {
    type: String,
    required: true
  },
  state: {
    type: String,
    required: true
  },
  location: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number],
      default: undefined,
      validate: { validator: v => v == null || (v.length === 2 && v.every(Number.isFinite) && Math.abs(v[0]) <= 180 && Math.abs(v[1]) <= 90), message: 'Coordinates must be valid [longitude, latitude]' }
    },
    default: undefined
  },
  phone: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  hours: {
    type: String,
    default: '9:00 AM - 7:00 PM'
  },
  vehicleTypes: {
    type: [String],
    enum: ['car', 'bike'],
    required: true
  },
  photos: [String],
  services: [String],
  specialties: [String],
  description: String,
  ratings: {
    average: {
      type: Number,
      default: 0
    },
    count: {
      type: Number,
      default: 0
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index for geospatial queries
showroomSchema.index({ location: '2dsphere' });

module.exports = mongoose.model('Showroom', showroomSchema);
