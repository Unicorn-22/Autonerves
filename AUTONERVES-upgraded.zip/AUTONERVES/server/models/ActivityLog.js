const mongoose = require('mongoose');
const activityLogSchema = new mongoose.Schema({
  car: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle', default: null, index: true },
  showroom: { type: mongoose.Schema.Types.ObjectId, ref: 'Showroom', default: null, index: true },
  eventType: { type: String, enum: ['car_viewed','car_searched','comparison_added','showroom_viewed','enquiry_submitted'], required: true, index: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null, index: true },
  sessionId: { type: String, maxlength: 128, default: null },
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
  createdAt: { type: Date, default: Date.now, index: true }
}, { versionKey: false });
activityLogSchema.index({ showroom: 1, createdAt: -1 });
module.exports = mongoose.model('ActivityLog', activityLogSchema);
