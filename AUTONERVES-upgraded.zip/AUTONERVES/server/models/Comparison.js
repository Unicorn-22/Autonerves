const mongoose = require('mongoose');
const schema = new mongoose.Schema({ user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, cars: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle' }] }, { timestamps: true });
schema.index({ user: 1 });
module.exports = mongoose.model('Comparison', schema);
