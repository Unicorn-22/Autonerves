const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  vehicle: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle', required: true, index: true },
  name: { type: String, required: true, trim: true },
  year: { type: Number, min: 1886, max: 2100 },
  exShowroomPrice: { type: Number, min: 0 },
  onRoadPrice: { type: Number, min: 0 },
  specifications: { type: mongoose.Schema.Types.Mixed, default: {} },
  isDemo: { type: Boolean, default: true },
  priceIsDemo: { type: Boolean, default: true },
  source: { type: String, default: 'Unverified / demo' },
  lastUpdatedAt: Date
}, { timestamps: true });
schema.index({ vehicle: 1, name: 1 }, { unique: true });
module.exports = mongoose.model('CarVariant', schema);
