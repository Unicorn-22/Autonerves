const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['car', 'bike'],
    required: true
  },
  brand: {
    type: String,
    required: true
  },
  model: {
    type: String,
    required: true
  },
  category: {
    type: String,
  },
  year: {
    type: Number,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  currency: {
    type: String,
    enum: ['INR', 'USD'],
    default: 'INR'
  },
  variant: { type: String, default: '' },
  bodyType: { type: String, default: '' },
  priceOnRoad: { type: Number, min: 0 },
  priceIsDemo: { type: Boolean, default: true },
  isDemo: { type: Boolean, default: true },
  source: { type: String, default: 'Not supplied' },
  sourceUpdatedAt: { type: Date },
  safetyRating: { type: String, default: '' },
  airbags: { type: Number, min: 0 },
  abs: { type: Boolean },
  esp: { type: Boolean },
  exteriorImages: [String],
  interiorImages: [String],
  showroom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Showroom',
    required: true
  },
  images: [String],
  description: String,
  specifications: {
    engine: String,
    transmission: String,
    mileage: String,
    mileageValue: { type: Number, min: 0 },
    fuelType: String,
    seatingCapacity: Number,
    horsepower: Number,
    colors: [String],
    features: [String],
    torque: String,
    range: String,
    infotainment: [String]
  },
  views: { type: Number, default: 0, min: 0 },
  available: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Create indexes for common queries
vehicleSchema.index({ type: 1, brand: 1, model: 1 });
vehicleSchema.index({ showroom: 1 });
vehicleSchema.index({ price: 1 });
vehicleSchema.index({ category: 1 });
vehicleSchema.index({ brand: 1, model: 1, year: -1 });
vehicleSchema.index({ 'specifications.fuelType': 1, 'specifications.transmission': 1 });

module.exports = mongoose.model('Vehicle', vehicleSchema, 'vehicles-finder');
