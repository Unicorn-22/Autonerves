const mongoose = require('mongoose');
const enquirySchema = new mongoose.Schema({
  car: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle', required: true, index: true },
  showroom: { type: mongoose.Schema.Types.ObjectId, ref: 'Showroom', required: true, index: true },
  customer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  name: { type: String, required: true, trim: true, maxlength: 100 },
  email: { type: String, required: true, trim: true, lowercase: true },
  phone: { type: String, trim: true, maxlength: 20 },
  message: { type: String, required: true, maxlength: 2000 },
  status: { type: String, enum: ['new','contacted','closed'], default: 'new', index: true },
  createdAt: { type: Date, default: Date.now }
}, { timestamps: true });
module.exports = mongoose.model('Enquiry', enquirySchema);
