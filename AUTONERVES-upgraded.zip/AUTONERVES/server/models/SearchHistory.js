const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null, index: true },
  sessionId: { type: String, maxlength: 128, default: null },
  query: { type: String, maxlength: 120, default: '' },
  filters: { type: mongoose.Schema.Types.Mixed, default: {} },
  resultCount: { type: Number, min: 0, default: 0 },
  createdAt: { type: Date, default: Date.now, index: true }
}, { versionKey: false });
module.exports = mongoose.model('SearchHistory', schema);
