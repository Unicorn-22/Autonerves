const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const dotenv = require("dotenv");
const morgan = require("morgan");
const helmet = require("helmet");
const path = require("path");
const connectDB = require("./config/db");
const passport = require("passport");
const session = require("express-session");

// Load environment variables before configuring Passport.
dotenv.config();

// Passport config
require("./config/passport");

// Connect to database
connectDB();

const app = express();

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
const allowedOrigins = (process.env.CORS_ORIGIN || 'http://localhost:5173').split(',').map(value => value.trim());
app.use(cors({ origin: (origin, callback) => {
  if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) return callback(null, true);
  return callback(new Error('Origin is not allowed by CORS'));
} }));
app.use(helmet());
app.use(morgan("dev"));

// Session middleware is enabled only when configured (required for OAuth sessions).
if (process.env.SESSION_SECRET) {
  app.use(session({ secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false }));
}
app.use(passport.initialize());
if (process.env.SESSION_SECRET) app.use(passport.session());

// Set up routes
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/vehicles", require("./routes/vehicleRoutes"));
app.use("/api/showrooms", require("./routes/showroomRoutes"));
app.use("/api/admin", require("./routes/adminRoutes"));
app.use("/api/activity", require("./routes/activityRoutes"));
app.use("/api/enquiries", require("./routes/enquiryRoutes"));
app.use("/api/favourites", require("./routes/favouriteRoutes"));
app.use("/api/comparisons", require("./routes/comparisonRoutes"));

// Serve uploaded files
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    message: err.message || "Something went wrong!",
  });
});

// Start server
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
