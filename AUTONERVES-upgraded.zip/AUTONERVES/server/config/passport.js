require("dotenv").config();
const passport = require("passport");
const GoogleStrategy = require("passport-google-oauth20").Strategy;
const User = require("../models/User");

passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID, // Must be defined
      clientSecret: process.env.GOOGLE_CLIENT_SECRET, // Must be defined
      callbackURL: "http://localhost:5000/api/auth/google/callback", // Adjust to your route
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        // Build new user object from profile
        const newUser = {
          googleId: profile.id,
          name: profile.displayName,
          email: profile.emails[0].value,
          provider: "google",
        };

        // Check if user already exists
        let user = await User.findOne({ email: profile.emails[0].value });

        if (user) {
          // If user exists but no googleId, update it
          if (!user.googleId) {
            user.googleId = profile.id;
            user.provider = "google";
            await user.save();
          }
          return done(null, user);
        } else {
          // Create new user
          user = await User.create(newUser);
          return done(null, user);
        }
      } catch (err) {
        console.error("Passport Google OAuth error:", err);
        return done(err, null);
      }
    }
  )
);

// Serialize user ID to session
passport.serializeUser((user, done) => {
  done(null, user.id);
});

// Deserialize user from ID in session
passport.deserializeUser((id, done) => {
  User.findById(id)
    .then((user) => done(null, user))
    .catch((err) => done(err, null));
});
