# AUTONERVES — upgraded existing project

MERN application: React 19 + Vite + Tailwind CSS, Express 5, MongoDB/Mongoose, JWT authentication, Leaflet + OpenStreetMap.

## Run locally

Prerequisites: Node.js 20+, npm, and MongoDB running locally or a MongoDB connection string.

1. Configure the backend:
   ```bash
   cd server
   cp .env.example .env
   ```
   Set `MONGODB_URI`, `JWT_SECRET`, and `SESSION_SECRET` to your own values. Do not commit `.env`.
2. Install and seed demo data:
   ```bash
   npm ci
   npm run seed
   npm start
   ```
   API default: `http://localhost:5000`.
3. In another terminal:
   ```bash
   cd client
   cp .env.example .env
   npm ci
   npm run dev
   ```
   Vite default: `http://localhost:5173`.

## Environment variables

Backend (`server/.env`):
- `PORT` — API port (default 5000)
- `MONGODB_URI` — MongoDB connection string
- `JWT_SECRET` — long random JWT signing secret
- `SESSION_SECRET` — separate long random session secret; required for Passport session/OAuth
- `NODE_ENV` — development or production\n- `CORS_ORIGIN` — comma-separated allowed frontend origins (for local development: `http://localhost:5173`)\n- `CLIENT_URL` — frontend redirect target for OAuth (default `http://localhost:5173`)
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` — optional Google OAuth credentials

Frontend (`client/.env`):
- `VITE_API_URL` — API base URL, default `http://localhost:5000/api`
- `VITE_GOOGLE_MAPS_API_KEY` — retained only for any legacy Google Maps integrations; the showroom locator now uses free OpenStreetMap tiles and Leaflet.

## Demo accounts

The seed script creates:
- Super Admin: `admin@example.com` / `admin123`
- Showroom Admin: `dealer@example.com` / `password123`
- Customer: `buyer@example.com` / `buyer123`

Change these passwords before exposing the app to any network. Public registration always creates a customer; showroom admin accounts are created by the Super Admin dashboard.

## What is implemented in this upgrade

- Removed the active NHTSA Variables page, route, and navigation links.
- Expanded vehicle and showroom schemas with variant, price provenance, demo labels, safety/specification fields, location validation, and indexes.
- Added CarVariant, ShowroomInventory, ActivityLog, SearchHistory, Enquiry, Favourite, and Comparison models.
- Added customer enquiry submission/status view, saved-car actions/list, and server-persisted comparison selections for authenticated users.
- Added consent-gated car view/search/comparison/showroom activity tracking. Enquiry submission is recorded as an operational event.
- Added Super Admin overview metrics, showroom performance aggregation, showroom-admin account creation, and account activation/deactivation.
- Added showroom-scoped analytics and server-side authorization for showroom inventory changes.
- Rebuilt the showroom locator around Leaflet/OpenStreetMap. It shows markers only for non-demo showrooms with valid coordinates; demo locations are labelled unverified and are not plotted.
- Added vehicle search filters and sorting for brand, price, fuel, transmission, body type, year, seats, horsepower, latest, price, and views.
- Added API base URL configuration and safer environment templates.

## MongoDB collections / models

`User`, `Showroom`, `Vehicle` (stored in the existing `vehicles-finder` collection), `CarVariant`, `ShowroomInventory`, `SearchHistory`, `ActivityLog`, `Enquiry`, `Favourite`, and `Comparison`. Collections are created by MongoDB/Mongoose when first written; indexes are declared in the model schemas.

## Data quality

The seed script is non-destructive: it adds missing demo records and does not clear existing dealer inventory. The bundled seed data is demo data. Its prices/specifications and sample showroom locations are not verified live market listings. Demo cars are marked `isDemo` / `priceIsDemo`, with source metadata. Demo showroom coordinates are not displayed as real map pins. Add verified market records and real showroom coordinates before production use. Safety ratings are not inferred or fabricated.

## Important production follow-ups

- Rotate all demo passwords and configure strong secrets.
- Add HTTPS, production CORS allowlists, rate limiting, audit/retention policies, and email verification.
- Complete full browser/API testing against your own MongoDB instance and real showroom data.
- Configure OAuth credentials only if Google login is required.
