import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import { LogOut, Menu, Shield, Store, User } from 'lucide-react';
import { AuthContext } from '../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Sheet, SheetTrigger, SheetContent, SheetHeader, SheetTitle, SheetClose } from '@/components/ui/sheet';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import CartSheet from './CartSheet';
import { cn } from '@/lib/utils';

const links = [
  { to: '/vehicles', label: 'Vehicles' },
  { to: '/showrooms', label: 'Showrooms' },
  { to: '/compare', label: 'Compare' },
];

const Navbar = () => {
  const navigate = useNavigate();
  const { isAuthenticated, user, logout } = useContext(AuthContext);
  const canManage = user?.role === 'dealer' || user?.role === 'admin';
  const handleLogout = () => { logout(); navigate('/'); };
  const linkCls = ({ isActive }) => cn('relative text-sm font-medium transition-colors hover:text-primary', isActive ? 'text-primary after:absolute after:-bottom-[22px] after:left-0 after:h-0.5 after:w-full after:bg-gradient-brand' : 'text-muted-foreground');

  return (
    <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur">
      <div className="container flex h-[70px] items-center justify-between">
        <Link to="/" className="unica-one-regular text-gradient text-3xl md:text-4xl">AUTONERVES</Link>

        <nav className="hidden items-center gap-8 md:flex">
          {links.map((l) => <NavLink key={l.to} to={l.to} className={linkCls}>{l.label}</NavLink>)}
        </nav>

        <div className="flex items-center gap-1">
          <CartSheet />
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2"><User /><span className="hidden sm:inline">{user?.name}</span></Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>{user?.name}<span className="block text-xs font-normal capitalize text-muted-foreground">{user?.role}</span></DropdownMenuLabel>
                <DropdownMenuSeparator />
                {user?.role === 'buyer' && <DropdownMenuItem onSelect={() => navigate('/favourites')}>Saved cars</DropdownMenuItem>}
                {user?.role === 'buyer' && <DropdownMenuItem onSelect={() => navigate('/my-enquiries')}>My enquiries</DropdownMenuItem>}
                {canManage && <DropdownMenuItem onSelect={() => navigate('/manage-enquiries')}>Showroom enquiries</DropdownMenuItem>}
                {canManage && <DropdownMenuItem onSelect={() => navigate('/manage-showroom')}><Store />My Showroom</DropdownMenuItem>}
                {user?.role === 'admin' && <DropdownMenuItem onSelect={() => navigate('/admin')}><Shield />Admin Panel</DropdownMenuItem>}
                <DropdownMenuItem onSelect={handleLogout} className="text-red-400 focus:text-red-400"><LogOut />Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="hidden items-center gap-2 sm:flex">
              <Button asChild variant="ghost"><Link to="/login">Login</Link></Button>
              <Button asChild variant="gradient"><Link to="/register">Register</Link></Button>
            </div>
          )}

          <Sheet>
            <SheetTrigger asChild><Button variant="ghost" size="icon" className="md:hidden" aria-label="Menu"><Menu /></Button></SheetTrigger>
            <SheetContent side="left">
              <SheetHeader><SheetTitle className="unica-one-regular text-gradient text-2xl">AUTONERVES</SheetTitle></SheetHeader>
              <div className="flex flex-col gap-1">
                {links.map((l) => <SheetClose asChild key={l.to}><Link to={l.to} className="rounded-md px-3 py-2.5 text-muted-foreground hover:bg-accent hover:text-foreground">{l.label}</Link></SheetClose>)}
                {!isAuthenticated && (<>
                  <SheetClose asChild><Link to="/login" className="rounded-md px-3 py-2.5 text-muted-foreground hover:bg-accent hover:text-foreground">Login</Link></SheetClose>
                  <SheetClose asChild><Link to="/register" className="rounded-md px-3 py-2.5 text-primary hover:bg-accent">Register</Link></SheetClose>
                </>)}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};
export default Navbar;
