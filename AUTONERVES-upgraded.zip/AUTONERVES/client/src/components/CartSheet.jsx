import { Link } from 'react-router-dom';
import { Minus, Plus, ShoppingCart, Trash2 } from 'lucide-react';
import { Sheet, SheetTrigger, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetClose } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/lib/format';

const CartSheet = () => {
  const { items, count, setQuantity, removeItem, clear } = useCart();
  // Totals are per currency so INR and USD listings are never silently added together.
  const totals = items.reduce((t, i) => ({ ...t, [i.currency]: (t[i.currency] || 0) + i.price * i.quantity }), {});

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Open cart">
          <ShoppingCart />
          {count > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-xs font-bold">{count}</span>}
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Your Cart</SheetTitle>
          <SheetDescription>{count} item{count === 1 ? '' : 's'} saved on this device</SheetDescription>
        </SheetHeader>
        <div className="-mx-2 flex-1 space-y-3 overflow-y-auto px-2">
          {items.length === 0 && <p className="py-12 text-center text-muted-foreground">Your cart is empty.</p>}
          {items.map((i) => (
            <div key={i.id} className="flex gap-3 rounded-lg border bg-secondary/30 p-3">
              {i.image && <img src={i.image} alt="" className="h-16 w-20 rounded-md object-cover" />}
              <div className="min-w-0 flex-1">
                <Link to={`/vehicle/${i.id}`} className="block truncate font-semibold hover:text-primary">{i.name}</Link>
                <p className="text-sm text-primary">{formatPrice(i.price, i.currency)}</p>
                <div className="mt-2 flex items-center gap-2">
                  <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => setQuantity(i.id, i.quantity - 1)}><Minus /></Button>
                  <span className="w-6 text-center text-sm">{i.quantity}</span>
                  <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => setQuantity(i.id, i.quantity + 1)}><Plus /></Button>
                  <Button size="icon" variant="ghost" className="ml-auto h-7 w-7 text-red-400" onClick={() => removeItem(i.id)}><Trash2 /></Button>
                </div>
              </div>
            </div>
          ))}
        </div>
        {items.length > 0 && (
          <div className="space-y-3 border-t pt-4">
            {Object.entries(totals).map(([cur, amt]) => (
              <div key={cur} className="flex justify-between text-lg font-bold"><span>Total ({cur})</span><span className="text-gradient">{formatPrice(amt, cur)}</span></div>
            ))}
            <SheetClose asChild><Button asChild variant="gradient" className="w-full"><Link to="/showrooms">Find a showroom to enquire</Link></Button></SheetClose>
            <Button variant="ghost" className="w-full text-muted-foreground" onClick={clear}>Clear cart</Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
};
export default CartSheet;
