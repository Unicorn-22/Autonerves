import { cva } from 'class-variance-authority'
import { cn } from '@/lib/utils'

const badgeVariants = cva('inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors', {
  variants: {
    variant: {
      default: 'border-primary/40 bg-primary/15 text-primary',
      secondary: 'border-transparent bg-secondary text-secondary-foreground',
      success: 'border-emerald-500/30 bg-emerald-500/15 text-emerald-400',
      destructive: 'border-red-500/30 bg-red-500/15 text-red-400',
      outline: 'text-foreground',
    },
  },
  defaultVariants: { variant: 'default' },
})
export function Badge({ className, variant, ...props }) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />
}
export { badgeVariants }
