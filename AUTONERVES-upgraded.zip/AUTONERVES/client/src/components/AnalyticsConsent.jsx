import { useState } from 'react';
export default function AnalyticsConsent() {
  const [choice, setChoice] = useState(() => localStorage.getItem('autonerves_analytics_consent'));
  const [settingsOpen, setSettingsOpen] = useState(false);
  const save = value => { localStorage.setItem('autonerves_analytics_consent', value); setChoice(value); setSettingsOpen(false); };
  if (choice && !settingsOpen) return <button onClick={() => setSettingsOpen(true)} className="fixed bottom-3 left-3 z-40 rounded-full border bg-background px-3 py-2 text-xs shadow">Privacy settings</button>;
  return <aside className="fixed bottom-3 left-3 right-3 z-50 mx-auto max-w-3xl rounded-xl border bg-background p-4 shadow-xl">
    <p className="font-semibold">Privacy preferences</p>
    <p className="mt-1 text-sm text-muted-foreground">AUTONERVES can record car views, searches and showroom interactions to provide showroom analytics. This is optional. No passwords are included in analytics.</p>
    <div className="mt-3 flex flex-wrap gap-2"><button onClick={() => save('yes')} className="rounded-md bg-primary px-4 py-2 text-sm text-primary-foreground">Allow analytics</button><button onClick={() => save('no')} className="rounded-md border px-4 py-2 text-sm">Decline</button></div>
  </aside>;
}
