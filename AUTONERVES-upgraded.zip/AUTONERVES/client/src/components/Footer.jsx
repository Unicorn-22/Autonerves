import { Link } from 'react-router-dom';

const col = 'text-muted-foreground transition-colors hover:text-primary';

const Footer = () => (
  <footer className="mt-16 border-t bg-card/50">
    <div className="container py-12">
      <div className="grid gap-10 md:grid-cols-4">
        <div className="md:col-span-2">
          <h3 className="unica-one-regular text-gradient mb-3 text-3xl">AUTONERVES</h3>
          <p className="max-w-md text-muted-foreground">Find the best vehicle showrooms near you, browse cars, bikes and EVs, and compare them side by side.</p>
        </div>
        <div>
          <h4 className="mb-4 font-semibold">Quick Links</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/vehicles" className={col}>Search Vehicles</Link></li>
            <li><Link to="/showrooms" className={col}>Find Showrooms</Link></li>
            <li><Link to="/compare" className={col}>Compare Vehicles</Link></li>
            <li><Link to="/register" className={col}>Register</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 font-semibold">Contact Us</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>Email: info@showroomfinder.com</li>
            <li>Phone: +91 9876543210</li>
          </ul>
        </div>
      </div>
      <div className="mt-10 border-t pt-6 text-center text-sm text-muted-foreground">
        &copy; {new Date().getFullYear()} AUTONERVES (ShowroomFinder). All rights reserved.
      </div>
    </div>
  </footer>
);
export default Footer;
