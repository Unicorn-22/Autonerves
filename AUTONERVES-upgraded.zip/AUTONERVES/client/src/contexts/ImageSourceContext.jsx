import React, { createContext, useState, useContext } from 'react';

const ImageSourceContext = createContext();

export const useImageSource = () => useContext(ImageSourceContext);

export const ImageSourceProvider = ({ children }) => {
  const [useDbImages, setUseDbImages] = useState(false);

  const value = {
    useDbImages,
    setUseDbImages,
  };

  return (
    <ImageSourceContext.Provider value={value}>
      {children}
    </ImageSourceContext.Provider>
  );
};
