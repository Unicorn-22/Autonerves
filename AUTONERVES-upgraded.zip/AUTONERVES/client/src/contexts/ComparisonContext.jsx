import React, { createContext, useState, useContext, useEffect } from 'react';
import comparisonService from '../services/comparisonService';
const ComparisonContext = createContext();
export const useComparison = () => useContext(ComparisonContext);
export const ComparisonProvider = ({ children }) => {
  const [selectedVehicles, setSelectedVehicles] = useState([]);
  useEffect(() => {
    if (localStorage.getItem('token')) comparisonService.getComparison().then(setSelectedVehicles).catch(() => {});
  }, []);
  const persist = next => { setSelectedVehicles(next); if (localStorage.getItem('token')) comparisonService.saveComparison(next.map(v => v._id)).catch(() => {}); };
  const toggleComparison = vehicle => {
    const exists = selectedVehicles.some(v => v._id === vehicle._id);
    const next = exists ? selectedVehicles.filter(v => v._id !== vehicle._id) : selectedVehicles.length < 2 ? [...selectedVehicles, vehicle] : [selectedVehicles[1], vehicle];
    persist(next);
  };
  const clearComparison = () => persist([]);
  return <ComparisonContext.Provider value={{ selectedVehicles, toggleComparison, clearComparison }}>{children}</ComparisonContext.Provider>;
};
