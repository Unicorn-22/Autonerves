import { createContext, useContext, useEffect, useMemo, useState } from 'react';

// Cart ported from docs/design-reference/shadcn-ui/js/app.js (addToCart / updateCartQuantity / removeFromCart).
// Persisted per-browser in localStorage; stores a snapshot of what the card needs.
const CartContext = createContext(null);
const KEY = 'autonerves.cart';

const load = () => {
  try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; }
};

export const CartProvider = ({ children }) => {
  const [items, setItems] = useState(load);
  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(items)); } catch { /* storage unavailable */ }
  }, [items]);

  const api = useMemo(() => ({
    items,
    count: items.reduce((n, i) => n + i.quantity, 0),
    addItem: (v) => setItems((p) => p.some((i) => i.id === v._id)
      ? p.map((i) => (i.id === v._id ? { ...i, quantity: i.quantity + 1 } : i))
      : [...p, { id: v._id, name: `${v.brand} ${v.model}`, price: v.price, currency: v.currency || 'INR', image: v.images?.[0] || null, quantity: 1 }]),
    setQuantity: (id, q) => setItems((p) => (q <= 0 ? p.filter((i) => i.id !== id) : p.map((i) => (i.id === id ? { ...i, quantity: q } : i)))),
    removeItem: (id) => setItems((p) => p.filter((i) => i.id !== id)),
    clear: () => setItems([]),
  }), [items]);

  return <CartContext.Provider value={api}>{children}</CartContext.Provider>;
};

export const useCart = () => useContext(CartContext);
