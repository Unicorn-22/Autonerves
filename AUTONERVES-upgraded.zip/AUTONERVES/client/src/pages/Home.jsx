import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { formatPrice } from '@/lib/format';
import vehicleService from "../services/vehicleService";
import { getVehicleImage, PLACEHOLDER_IMAGE } from "../utils/vehicleImages";
import { useImageSource } from "../contexts/ImageSourceContext";
// import img from '../../public/images/desktop-wallpaper-machindra-thar-thar-car.jpg'

const Home = () => {
  const { useDbImages } = useImageSource();
  const [featuredVehicles, setFeaturedVehicles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeaturedVehicles = async () => {
      try {
        // Fetch some vehicles to display on homepage
        const { vehicles } = await vehicleService.getAllVehicles(1, 6);
        setFeaturedVehicles(vehicles);
      } catch (error) {
        console.error("Error fetching featured vehicles:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchFeaturedVehicles();
  }, []);

  return (
    <div>
      {/* Hero Section — layout/style follows docs/design-reference/shadcn-ui hero */}
      <section className="relative flex min-h-[80vh] items-center justify-center overflow-hidden border-b">
        <div
          className="absolute inset-0 -z-10"
          style={{
            backgroundImage: "linear-gradient(rgba(0,0,0,.72), rgba(0,0,0,.55)), url('/images/vehicles/thar.jpg')",
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="hero-glow absolute inset-0 -z-10" />
        <div className="container max-w-4xl animate-fade-in-up py-24 text-center">
          <Badge className="mb-6 px-4 py-2 text-sm">Premium Vehicle Marketplace</Badge>
          <h1 className="text-gradient mb-6 text-4xl font-bold leading-tight md:text-6xl">
            Find Your Perfect Vehicle at the Best Showrooms
          </h1>
          <p className="mx-auto mb-10 max-w-3xl text-lg text-muted-foreground md:text-xl">
            Discover nearby showrooms with real-time inventory, compare prices,
            and find the best deals on cars and bikes.
          </p>
          <div className="flex flex-col justify-center gap-4 sm:flex-row">
            <Button asChild size="lg" variant="gradient"><Link to="/vehicles">Search Vehicles <ArrowRight /></Link></Button>
            <Button asChild size="lg" variant="outline"><Link to="/showrooms">Find Nearby Showrooms</Link></Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <div className="container mx-auto px-6">
        <section className="py-20 bg-card mt-5 rounded-2xl shadow-lg">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">
              Why Choose ShowroomFinder?
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Feature 1 */}
              <div className="bg-card p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary/15 text-primary w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3">
                  Locate Nearby Showrooms
                </h3>
                <p className="text-muted-foreground">
                  Find showrooms near your location with real-time distance
                  calculation and accurate mapping.
                </p>
              </div>

              {/* Feature 2 */}
              <div className="bg-card p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary/15 text-primary w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3">
                  Compare Vehicle Options
                </h3>
                <p className="text-muted-foreground">
                  Compare prices, specifications, and features of different
                  vehicles side by side.
                </p>
              </div>

              {/* Feature 3 */}
              <div className="bg-card p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary/15 text-primary w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3">
                  Real-Time Inventory
                </h3>
                <p className="text-muted-foreground">
                  Get up-to-date information about vehicle availability at each
                  showroom.
                </p>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Featured Vehicles Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">
            Featured Vehicles
          </h2>

          {loading ? (
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : featuredVehicles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredVehicles.map((vehicle) => (
                <div
                  key={vehicle._id}
                  className="bg-card rounded-lg shadow-md overflow-hidden"
                >
                  <div className="h-48 overflow-hidden">
                    <img
                      src={
                        useDbImages
                          ? vehicle.images[0] || PLACEHOLDER_IMAGE
                          : getVehicleImage(vehicle.brand, vehicle.model, vehicle)
                      }
                      alt={`${vehicle.brand} ${vehicle.model}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="text-xl font-bold mb-2">
                      {vehicle.brand} {vehicle.model}
                    </h3>
                    <div className="flex justify-between mb-2">
                      <span className="text-muted-foreground">Price:</span>
                      <span className="font-semibold">
                        {formatPrice(vehicle)}
                      </span>
                    </div>
                    <div className="flex justify-between mb-3">
                      <span className="text-muted-foreground">Showroom:</span>
                      <span>{vehicle.showroom?.name || 'N/A'}</span>
                    </div>
                    <Link
                      to={`/vehicle/${vehicle._id}`}
                      className="block w-full py-2 bg-primary text-center text-white rounded-md hover:bg-primary/90 transition"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No featured vehicles available.</p>
            </div>
          )}

          <div className="text-center mt-10">
            <Link
              to="/vehicles"
              className="inline-block bg-primary text-white font-bold px-6 py-3 rounded-lg hover:bg-primary/90 transition"
            >
              View All Vehicles
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-transparent">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="relative">
              <div className="bg-card p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-4 font-bold">
                  1
                </div>
                <h3 className="text-xl font-semibold mb-3">Search Vehicles</h3>
                <p className="text-muted-foreground">
                  Search for your desired car or bike by brand, model, price
                  range, or location.
                </p>
              </div>
              <div className="hidden md:block absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2">
                <svg
                  className="w-6 h-6 text-muted-foreground"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10l-3.293-3.293a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="bg-card p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-4 font-bold">
                  2
                </div>
                <h3 className="text-xl font-semibold mb-3">Find Showrooms</h3>
                <p className="text-muted-foreground">
                  Discover showrooms near your location that have the vehicles
                  you're interested in.
                </p>
              </div>
              <div className="hidden md:block absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2">
                <svg
                  className="w-6 h-6 text-muted-foreground"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10l-3.293-3.293a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
              </div>
            </div>

            {/* Step 3 */}
            <div>
              <div className="bg-card p-6 rounded-lg shadow-md text-center">
                <div className="bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-4 font-bold">
                  3
                </div>
                <h3 className="text-xl font-semibold mb-3">Compare & Visit</h3>
                <p className="text-muted-foreground">
                  Compare options, get directions to the showroom, and find your
                  perfect vehicle!
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary text-white mb-3">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">
            Ready to Find Your Perfect Vehicle?
          </h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Join thousands of satisfied customers who found their dream cars and
            bikes using ShowroomFinder.
          </p>
          <Link
            to="/register"
            className="inline-block bg-card text-primary hover:bg-secondary font-bold px-6 py-3 rounded-lg transition"
          >
            Get Started Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
