import { useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';

const AuthCallback = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  useEffect(() => {
    const token = searchParams.get('token');
    const user = searchParams.get('user');

    if (token && user) {
      localStorage.setItem('token', token);
      localStorage.setItem('user', user);
      window.location.href = '/'; // Redirect to home and reload to update auth state
    } else {
      navigate('/login');
    }
  }, [searchParams, navigate]);

  return <div>Loading...</div>;
};

export default AuthCallback;
