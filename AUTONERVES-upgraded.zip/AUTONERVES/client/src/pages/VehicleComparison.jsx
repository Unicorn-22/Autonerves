import React from 'react';
import { formatPrice } from '@/lib/format';
import { useComparison } from '../contexts/ComparisonContext';
import { Link } from 'react-router-dom';
import { getVehicleImage, PLACEHOLDER_IMAGE } from '../utils/vehicleImages';
import { useImageSource } from '../contexts/ImageSourceContext';

const VehicleComparison = () => {
  const { selectedVehicles, clearComparison } = useComparison();
  const { useDbImages } = useImageSource();

  const renderComparisonRow = (label, key, vehicle1, vehicle2) => {
    const value1 = vehicle1.specifications?.[key] || vehicle1[key] || 'N/A';
    const value2 = vehicle2 ? (vehicle2.specifications?.[key] || vehicle2[key] || 'N/A') : null;

    const displayValue = (val) => {
      if (Array.isArray(val)) {
        return val.join(', ');
      }
      return val;
    };

    return (
      <tr key={label} className="border-b">
        <td className="py-3 px-4 font-semibold text-foreground/90">{label}</td>
        <td className="py-3 px-4">{displayValue(value1)}</td>
        {vehicle2 && <td className="py-3 px-4">{displayValue(value2)}</td>}
      </tr>
    );
  };

  if (selectedVehicles.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-3xl font-bold mb-4">Vehicle Comparison</h1>
        <div className="bg-card p-16 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold text-foreground/90 mb-4">Select Vehicles to Compare</h2>
          <p className="text-muted-foreground mb-6">Go to the search page to select vehicles you want to compare side-by-side.</p>
          <Link to="/vehicles" className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition">
            Go to Vehicle Search
          </Link>
        </div>
      </div>
    );
  }

  if (selectedVehicles.length === 1) {
    const vehicle1 = selectedVehicles[0];
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-3xl font-bold mb-4">Vehicle Comparison</h1>
        <div className="bg-card p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold text-foreground/90 mb-4">Add one more vehicle to compare</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="text-left">
                <h2 className="text-xl font-bold">{vehicle1.brand} {vehicle1.model}</h2>
                <img src={useDbImages ? (vehicle1.images?.[0] || PLACEHOLDER_IMAGE) : getVehicleImage(vehicle1.brand, vehicle1.model, vehicle1)} alt={`${vehicle1.brand} ${vehicle1.model}`} className="w-full h-40 object-cover rounded-md mt-2" />
                <p className="text-xl font-bold text-primary mt-2">{formatPrice(vehicle1)}</p>
            </div>
            <div className="text-center">
                <p className="text-muted-foreground mb-6">You have added one vehicle. Please select another one to start comparing.</p>
                <Link to="/vehicles" className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary/90 transition">
                    Back to Search
                </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const [vehicle1, vehicle2] = selectedVehicles;

  const specKeys = [
    { label: 'Year', key: 'year' },
    { label: 'Engine', key: 'engine' },
    { label: 'Transmission', key: 'transmission' },
    { label: 'Mileage', key: 'mileage' },
    { label: 'Fuel Type', key: 'fuelType' },
    { label: 'Seating Capacity', key: 'seatingCapacity' },
    { label: 'Available Colors', key: 'colors' },
    { label: 'Key Features', key: 'features' },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Vehicle Comparison</h1>
        <button
          onClick={clearComparison}
          className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition"
        >
          Clear Comparison
        </button>
      </div>

      <div className="bg-card rounded-lg shadow-md overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-secondary">
              <th className="py-4 px-4 w-1/4">Feature</th>
              <th className="py-4 px-4">
                <h2 className="text-xl font-bold">{vehicle1.brand} {vehicle1.model}</h2>
                <img src={useDbImages ? (vehicle1.images?.[0] || PLACEHOLDER_IMAGE) : getVehicleImage(vehicle1.brand, vehicle1.model, vehicle1)} alt={`${vehicle1.brand} ${vehicle1.model}`} className="w-full h-40 object-cover rounded-md mt-2" />
              </th>
              <th className="py-4 px-4">
                <h2 className="text-xl font-bold">{vehicle2.brand} {vehicle2.model}</h2>
                <img src={useDbImages ? (vehicle2.images?.[0] || PLACEHOLDER_IMAGE) : getVehicleImage(vehicle2.brand, vehicle2.model, vehicle2)} alt={`${vehicle2.brand} ${vehicle2.model}`} className="w-full h-40 object-cover rounded-md mt-2" />
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b bg-primary/10">
              <td className="py-3 px-4 font-semibold text-primary">Price</td>
              <td className="py-3 px-4 text-xl font-bold text-primary">{formatPrice(vehicle1)}</td>
              <td className="py-3 px-4 text-xl font-bold text-primary">{formatPrice(vehicle2)}</td>
            </tr>
            {specKeys.map(spec => renderComparisonRow(spec.label, spec.key, vehicle1, vehicle2))}
          </tbody>
        </table>
      </div>
       <div className="mt-8 bg-card rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold mb-4 text-center">Price Difference</h2>
          <div className="text-center">
            <div className="text-3xl font-bold text-emerald-400">{formatPrice(Math.abs(vehicle1.price - vehicle2.price), vehicle1.currency)}</div>
          </div>
        </div>
    </div>
  );
};

export default VehicleComparison;
