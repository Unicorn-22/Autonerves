import { useEffect, useState } from 'react';
import enquiryService from '../services/enquiryService';
import toast from 'react-hot-toast';
export default function EnquiryManagement() {
  const [items,setItems] = useState([]);
  const [loading,setLoading] = useState(true);
  useEffect(() => { enquiryService.getStaffEnquiries().then(setItems).catch(() => toast.error('Unable to load showroom enquiries.')).finally(() => setLoading(false)); }, []);
  const changeStatus = async (id,status) => {
    try { const updated = await enquiryService.updateEnquiryStatus(id,status); setItems(old=>old.map(x=>x._id===id?updated:x)); toast.success('Enquiry status updated.'); }
    catch (e) { toast.error(e.response?.data?.message || 'Could not update enquiry.'); }
  };
  return <main className="container mx-auto px-4 py-8"><h1 className="mb-6 text-3xl font-bold">Showroom enquiries</h1>{loading ? <p>Loading…</p> : items.length ? <div className="overflow-x-auto rounded-xl border"><table className="w-full text-left text-sm"><thead><tr className="border-b text-muted-foreground"><th className="p-3">Customer</th><th className="p-3">Vehicle</th><th className="p-3">Message</th><th className="p-3">Received</th><th className="p-3">Status</th></tr></thead><tbody>{items.map(item=><tr key={item._id} className="border-b align-top"><td className="p-3"><strong>{item.name}</strong><p>{item.email}</p><p>{item.phone}</p></td><td className="p-3">{item.car?.brand} {item.car?.model}</td><td className="max-w-sm p-3">{item.message}</td><td className="p-3">{new Date(item.createdAt).toLocaleString()}</td><td className="p-3"><select value={item.status} onChange={e=>changeStatus(item._id,e.target.value)} className="rounded border bg-background p-2"><option value="new">New</option><option value="contacted">Contacted</option><option value="closed">Closed</option></select></td></tr>)}</tbody></table></div> : <p className="text-muted-foreground">No enquiries received yet.</p>}</main>;
}
