import { useState, useEffect, useContext } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { formatPrice } from '@/lib/format';
import { AuthContext } from '../contexts/AuthContext';
import { useComparison } from '../contexts/ComparisonContext';
import { useImageSource } from '../contexts/ImageSourceContext';
import vehicleService from '../services/vehicleService';
import toast from 'react-hot-toast';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { getVehicleImage, PLACEHOLDER_IMAGE } from '../utils/vehicleImages';
import { trackActivity } from '../services/activityService';
import enquiryService from '../services/enquiryService';
import favouriteService from '../services/favouriteService';

const VehicleDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const { isAuthenticated } = useContext(AuthContext);
  const { selectedVehicles, toggleComparison } = useComparison();
  const { useDbImages } = useImageSource();
  const [vehicle, setVehicle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeImage, setActiveImage] = useState(0);
  const [similarVehicles, setSimilarVehicles] = useState([]);
  const [favourite, setFavourite] = useState(false);
  const [enquiry, setEnquiry] = useState({ name: '', email: '', phone: '', message: '' });
  const [sendingEnquiry, setSendingEnquiry] = useState(false);
  
  useEffect(() => {
    const fetchVehicleData = async () => {
      setLoading(true);
      try {
        const data = await vehicleService.getVehicleById(id);
        setVehicle(data);
        trackActivity('car_viewed', { carId: data._id });
        
        // Fetch similar vehicles (same type and brand)
        fetchSimilarVehicles(data);
      } catch (error) {
        console.error('Error fetching vehicle details:', error);
        setError('Failed to load vehicle details. Please try again.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchVehicleData();
  }, [id]);
  
  useEffect(() => {
    if (vehicle?._id && isAuthenticated) favouriteService.getFavourites()
      .then(saved => setFavourite(saved.some(item => item.car?._id === vehicle._id))).catch(() => {});
  }, [vehicle?._id, isAuthenticated]);

  const fetchSimilarVehicles = async (vehicleData) => {
    try {
      // Search for similar vehicles (same type and brand, excluding current vehicle)
      const searchParams = {
        type: vehicleData.type,
        brand: vehicleData.brand,
        excludeId: vehicleData._id,
        limit: 3
      };
      
      const results = await vehicleService.searchVehicles(searchParams);
      setSimilarVehicles(results);
    } catch (error) {
      console.error('Error fetching similar vehicles:', error);
    }
  };
  
  const handleFavourite = async () => {
    if (!isAuthenticated) { toast.error('Please log in to save favourites.'); navigate('/login'); return; }
    try { const result = await favouriteService.toggleFavourite(vehicle._id); setFavourite(result.favourite); toast.success(result.favourite ? 'Saved to favourites' : 'Removed from favourites'); }
    catch { toast.error('Could not update favourites.'); }
  };
  const handleEnquiry = async (event) => {
    event.preventDefault();
    setSendingEnquiry(true);
    try {
      await enquiryService.submitEnquiry({ ...enquiry, carId: vehicle._id });
      setEnquiry({ name: '', email: '', phone: '', message: '' });
      toast.success('Your enquiry was sent to the showroom.');
    } catch (error) { toast.error(error.response?.data?.message || 'Unable to send enquiry.'); }
    finally { setSendingEnquiry(false); }
  };

  const handleGetDirections = () => {
    if (vehicle && vehicle.showroom && !vehicle.showroom.isDemo && vehicle.showroom.location?.coordinates?.length === 2) {
      const coords = vehicle.showroom.location.coordinates;
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${coords[1]},${coords[0]}`, '_blank');
    } else {
      toast.error('Showroom location information is not available');
    }
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (error || !vehicle) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-red-400 mb-4">Error</h2>
        <p className="mb-6">{error || 'Vehicle not found'}</p>
        <Link 
          to="/vehicles" 
          className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition"
        >
          Back to Search
        </Link>
      </div>
    );
  }
  
  const images = useDbImages
    ? (vehicle.images && vehicle.images.length > 0 ? vehicle.images : [PLACEHOLDER_IMAGE])
    : [getVehicleImage(vehicle.brand, vehicle.model, vehicle)];
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link to="/vehicles" className="text-primary hover:text-primary flex items-center">
          <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Back to Search
        </Link>
      </div>
      
      <div className="bg-card shadow-lg rounded-lg overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Vehicle Images */}
          <div className="p-6" data-aos="fade-right">
            <div className="mb-4 h-80 md:h-96 overflow-hidden rounded-lg bg-secondary shadow-inner">
              <img
                key={activeImage}
                src={images[activeImage]}
                alt={`${vehicle.brand} ${vehicle.model}`}
                className="w-full h-full object-cover fade-in-image"
              />
            </div>
            
            {images.length > 1 && (
              <div className="flex space-x-3 overflow-x-auto pb-2">
                {images.map((image, index) => (
                  <div
                    key={index}
                    className={`h-20 w-20 flex-shrink-0 cursor-pointer rounded-md overflow-hidden transition-all duration-300 ${
                      activeImage === index ? 'ring-2 ring-offset-2 ring-ring' : 'opacity-70 hover:opacity-100 hover:ring-2 hover:ring-border'
                    }`}
                    onClick={() => setActiveImage(index)}
                  >
                    <img
                      src={image}
                      alt={`Thumbnail ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Vehicle Details */}
          <div className="p-6">
            <h1 className="text-3xl font-bold mb-2">{vehicle.brand} {vehicle.model}</h1>
            <p className="text-muted-foreground mb-4">{vehicle.year}</p>
            
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-primary">{formatPrice(vehicle)}</h2>
              {vehicle.priceIsDemo ? <p className="mt-1 text-xs text-amber-600">Unverified / demo price · not a current quote</p> : vehicle.source && <p className="mt-1 text-xs text-muted-foreground">Source provided: {vehicle.source} · {vehicle.sourceUpdatedAt ? new Date(vehicle.sourceUpdatedAt).toLocaleDateString() : 'date unavailable'} (not independently verified)</p>}
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Specifications</h3>
              <div className="grid grid-cols-2 gap-4">
                {vehicle.specifications.engine && (
                  <div>
                    <span className="text-muted-foreground text-sm">Engine:</span>
                    <p>{vehicle.specifications.engine}</p>
                  </div>
                )}
                {vehicle.specifications.transmission && (
                  <div>
                    <span className="text-muted-foreground text-sm">Transmission:</span>
                    <p>{vehicle.specifications.transmission}</p>
                  </div>
                )}
                {vehicle.specifications.mileage && (
                  <div>
                    <span className="text-muted-foreground text-sm">Mileage:</span>
                    <p>{vehicle.specifications.mileage}</p>
                  </div>
                )}
                {vehicle.specifications.fuelType && (
                  <div>
                    <span className="text-muted-foreground text-sm">Fuel Type:</span>
                    <p>{vehicle.specifications.fuelType}</p>
                  </div>
                )}
                {vehicle.specifications.seatingCapacity && (
                  <div>
                    <span className="text-muted-foreground text-sm">Seating:</span>
                    <p>{vehicle.specifications.seatingCapacity} Persons</p>
                  </div>
                )}
              </div>
            </div>
            
            {vehicle.specifications.colors && vehicle.specifications.colors.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Available Colors</h3>
                <div className="flex flex-wrap gap-2">
                  {vehicle.specifications.colors.map((color, index) => (
                    <span 
                      key={index} 
                      className="inline-block bg-secondary rounded-full px-3 py-1 text-sm font-semibold text-foreground/90"
                    >
                      {color}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            {vehicle.description && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Description</h3>
                <p className="text-foreground/90">{vehicle.description}</p>
              </div>
            )}
            
            {vehicle.specifications.features && vehicle.specifications.features.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Key Features</h3>
                <ul className="grid grid-cols-2 gap-2">
                  {vehicle.specifications.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-foreground/90">
                      <svg className="w-4 h-4 text-emerald-400 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
        
        {/* Showroom Information */}
        {vehicle.showroom && (
          <div className="border-t border-border p-6">
            <h3 className="text-xl font-semibold mb-4">Available at</h3>
            <div className="bg-muted/50 p-4 rounded-lg">
              <div className="flex flex-col md:flex-row md:items-center justify-between">
                <div>
                  <h4 className="text-lg font-medium">{vehicle.showroom.name}</h4>
                  <p className="text-muted-foreground">{vehicle.showroom.address}</p>
                  <div className="mt-2 space-y-1">
                    <p className="text-muted-foreground flex items-center">
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                      </svg>
                      {vehicle.showroom.phone}
                    </p>
                    <p className="text-muted-foreground flex items-center">
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                      {vehicle.showroom.email}
                    </p>
                  </div>
                </div>
                <div className="mt-4 md:mt-0 flex space-x-3">
                  <Link
                    to={`/showroom/${vehicle.showroom._id}`}
                    className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition inline-block"
                  >
                    View Showroom
                  </Link>
                  <button
                    onClick={handleGetDirections}
                    className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition"
                  >
                    Get Directions
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {vehicle.showroom && <section className="mt-8 rounded-xl border bg-card p-6">
        <h2 className="mb-4 text-xl font-semibold">Enquire about this vehicle</h2>
        <form onSubmit={handleEnquiry} className="grid gap-3 md:grid-cols-2">
          <input required maxLength={100} placeholder="Your name" value={enquiry.name} onChange={e => setEnquiry(v => ({...v,name:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <input required type="email" placeholder="Email address" value={enquiry.email} onChange={e => setEnquiry(v => ({...v,email:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <input placeholder="Phone (optional)" value={enquiry.phone} onChange={e => setEnquiry(v => ({...v,phone:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <textarea required maxLength={2000} placeholder="Your message" value={enquiry.message} onChange={e => setEnquiry(v => ({...v,message:e.target.value}))} className="min-h-12 rounded-md border bg-background px-3 py-2 md:col-span-2" />
          <button disabled={sendingEnquiry} className="rounded-md bg-primary px-4 py-2 text-primary-foreground disabled:opacity-50 md:col-span-2">{sendingEnquiry ? 'Sending…' : 'Send enquiry'}</button>
        </form>
      </section>}

      {/* Similar Vehicles */}
      {similarVehicles.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Similar Vehicles</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {similarVehicles.map(similarVehicle => (
              <div key={similarVehicle._id} className="bg-card rounded-lg shadow-md overflow-hidden">
                <div className="h-48 overflow-hidden">
                  <img
                    src={useDbImages ? (similarVehicle.images?.[0] || PLACEHOLDER_IMAGE) : getVehicleImage(similarVehicle.brand, similarVehicle.model, similarVehicle)}
                    alt={`${similarVehicle.brand} ${similarVehicle.model}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-2">{similarVehicle.brand} {similarVehicle.model}</h3>
                  <div className="flex justify-between mb-2">
                    <span className="text-muted-foreground">Price:</span>
                    <span className="font-semibold">{formatPrice(similarVehicle)}</span>
                  </div>
                  <div className="flex justify-between mb-3">
                    <span className="text-muted-foreground">Showroom:</span>
                    <span>{similarVehicle.showroom?.name || 'N/A'}</span>
                  </div>
                  <Link 
                    to={`/vehicle/${similarVehicle._id}`}
                    className="block w-full py-2 bg-primary text-center text-white rounded-md hover:bg-primary/90 transition"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Add to Compare Button (Fixed at Bottom) */}
      <div className="fixed bottom-0 left-0 right-0 z-30 bg-background/95 backdrop-blur border-t border-border p-4 flex justify-center gap-3">
        <Button variant="gradient" onClick={() => { addItem(vehicle); toast.success("Added to cart"); }}>Add to Cart</Button>
        <Button variant={favourite ? "destructive" : "outline"} onClick={handleFavourite}>{favourite ? "Saved" : "Save favourite"}</Button>
        <Button
          variant={selectedVehicles.some((v) => v._id === vehicle._id) ? "destructive" : "outline"}
          onClick={() => {
            if (!isAuthenticated) {
              toast.error("Please log in or register to compare vehicles.");
              navigate('/register');
            } else {
              toggleComparison(vehicle);
              if (!selectedVehicles.some((v) => v._id === vehicle._id)) trackActivity('comparison_added', { carId: vehicle._id });
              toast.success(
                `${vehicle.brand} ${vehicle.model} ${
                  selectedVehicles.some((v) => v._id === vehicle._id)
                    ? 'removed from'
                    : 'added to'
                } comparison.`
              );
            }
          }}
        >
          {selectedVehicles.some((v) => v._id === vehicle._id)
            ? 'Remove from Compare'
            : 'Add to Compare'}
        </Button>
      </div>
    </div>
  );
};

export default VehicleDetails;
