import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { formatPrice } from '@/lib/format';
import { ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import toast from 'react-hot-toast';
import vehicleService from '../services/vehicleService';

import { getVehicleImage, PLACEHOLDER_IMAGE } from '../utils/vehicleImages';
import { useImageSource } from '../contexts/ImageSourceContext';

const VehicleListing = () => {
  const { addItem } = useCart();
  const { useDbImages } = useImageSource();
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
  });
  const [searchParams, setSearchParams] = useSearchParams();
  const [filter, setFilter] = useState(searchParams.get('category') || 'all');
  const [advanced, setAdvanced] = useState({ brand: '', model: '', minPrice: '', maxPrice: '', fuelType: '', transmission: '', bodyType: '', minYear: '', maxYear: '', minMileage: '', minSeats: '', minHp: '', sort: 'latest' });

  const page = parseInt(searchParams.get('page') || '1');

  useEffect(() => {
    const fetchVehicles = async () => {
      setLoading(true);
      try {
        const params = {
          page, limit: 24, category: filter === 'all' ? '' : filter,
          ...Object.fromEntries(Object.entries(advanced).filter(([key,value]) => value !== '' && !(key === 'sort' && value === 'latest')))
        };
        const data = await vehicleService.getAllVehicles(params);
        setVehicles(data.vehicles);
        setPagination({
          currentPage: data.currentPage,
          totalPages: data.totalPages,
        });
      } catch (error) {
        console.error("Error fetching vehicles:", error);
        toast.error("Failed to load vehicles.");
      } finally {
        setLoading(false);
      }
    };

    fetchVehicles();
  }, [page, filter, advanced]);

  const handlePageChange = (newPage) => {
    setSearchParams({ page: newPage, category: filter });
  };

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setSearchParams({ page: 1, category: newFilter });
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold text-foreground">Explore Our Vehicles</h1>
        <p className="mt-3 text-lg text-muted-foreground">Find the car or bike that best suits you.</p>
      </div>
      
      <section className="mb-8 rounded-2xl border bg-card p-4 md:p-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2"><h2 className="font-semibold">Find your car</h2><button onClick={() => setAdvanced({ brand: '', model: '', minPrice: '', maxPrice: '', fuelType: '', transmission: '', bodyType: '', minYear: '', maxYear: '', minMileage: '', minSeats: '', minHp: '', sort: 'latest' })} className="text-sm text-primary">Clear filters</button></div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <input aria-label="Brand" placeholder="Brand" value={advanced.brand} onChange={e => setAdvanced(v => ({...v,brand:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <input aria-label="Model" placeholder="Model" value={advanced.model} onChange={e => setAdvanced(v => ({...v,model:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <input aria-label="Minimum price" type="number" placeholder="Min price (₹)" value={advanced.minPrice} onChange={e => setAdvanced(v => ({...v,minPrice:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <input aria-label="Maximum price" type="number" placeholder="Max price (₹)" value={advanced.maxPrice} onChange={e => setAdvanced(v => ({...v,maxPrice:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <select aria-label="Fuel type" value={advanced.fuelType} onChange={e => setAdvanced(v => ({...v,fuelType:e.target.value}))} className="rounded-md border bg-background px-3 py-2"><option value="">Any fuel</option>{['Petrol','Diesel','CNG','Electric','Hybrid'].map(x => <option key={x}>{x}</option>)}</select>
          <select aria-label="Transmission" value={advanced.transmission} onChange={e => setAdvanced(v => ({...v,transmission:e.target.value}))} className="rounded-md border bg-background px-3 py-2"><option value="">Any transmission</option><option>Manual</option><option>Automatic</option></select>
          <select aria-label="Body type" value={advanced.bodyType} onChange={e => setAdvanced(v => ({...v,bodyType:e.target.value}))} className="rounded-md border bg-background px-3 py-2"><option value="">Any body type</option>{['SUV','Hatchback','Sedan','MUV','Coupe','MPV'].map(x => <option key={x}>{x}</option>)}</select>
          <input aria-label="Year from" type="number" placeholder="Year from" value={advanced.minYear} onChange={e => setAdvanced(v => ({...v,minYear:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <input aria-label="Year to" type="number" placeholder="Year to" value={advanced.maxYear} onChange={e => setAdvanced(v => ({...v,maxYear:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <input aria-label="Mileage at least" type="number" placeholder="Mileage at least (km/l)" value={advanced.minMileage} onChange={e => setAdvanced(v => ({...v,minMileage:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <input aria-label="Seats at least" type="number" placeholder="Seats at least" value={advanced.minSeats} onChange={e => setAdvanced(v => ({...v,minSeats:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <input aria-label="Horsepower at least" type="number" placeholder="Horsepower at least" value={advanced.minHp} onChange={e => setAdvanced(v => ({...v,minHp:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
          <select aria-label="Sort vehicles" value={advanced.sort} onChange={e => setAdvanced(v => ({...v,sort:e.target.value}))} className="rounded-md border bg-background px-3 py-2"><option value="latest">Latest models</option><option value="priceAsc">Price: low to high</option><option value="priceDesc">Price: high to low</option><option value="mostViewed">Most viewed</option></select>
        </div>
      </section>

      <div className="flex justify-center mb-10">
        <div className="flex flex-wrap space-x-1 bg-secondary p-1 rounded-xl">
          <button 
            onClick={() => handleFilterChange('all')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'all' ? 'bg-card text-primary shadow' : 'text-muted-foreground hover:bg-accent'}`}>
            All
          </button>
          <button 
            onClick={() => handleFilterChange('car')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'car' ? 'bg-card text-primary shadow' : 'text-muted-foreground hover:bg-accent'}`}>
            Cars
          </button>
          <button 
            onClick={() => handleFilterChange('bike')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'bike' ? 'bg-card text-primary shadow' : 'text-muted-foreground hover:bg-accent'}`}>
            Bikes
          </button>
          <button 
            onClick={() => handleFilterChange('ev')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'ev' ? 'bg-card text-primary shadow' : 'text-muted-foreground hover:bg-accent'}`}>
            EVs
          </button>
          <button 
            onClick={() => handleFilterChange('scooty')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'scooty' ? 'bg-card text-primary shadow' : 'text-muted-foreground hover:bg-accent'}`}>
            Scooters
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-primary"></div>
        </div>
      ) : vehicles.length > 0 ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {vehicles.map(vehicle => (
              <div key={vehicle._id} className="bg-card rounded-2xl shadow-md overflow-hidden group transform hover:-translate-y-2 transition-all duration-300 hover:shadow-xl border border-border/80" data-aos="fade-up">
                <div className="h-56 overflow-hidden relative">
                  <img
                    src={useDbImages ? (vehicle.images?.[0] || PLACEHOLDER_IMAGE) : getVehicleImage(vehicle.brand, vehicle.model, vehicle)}
                    alt={`${vehicle.brand} ${vehicle.model}`}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute top-0 right-0 bg-primary text-white px-3 py-1 text-xs font-bold rounded-bl-xl">
                    {vehicle.category ? vehicle.category.charAt(0).toUpperCase() + vehicle.category.slice(1) : vehicle.type.charAt(0).toUpperCase() + vehicle.type.slice(1)}
                  </div>
                </div>
                <div className="p-5">
                  <h2 className="text-xl font-bold text-foreground truncate mb-1">{vehicle.brand} {vehicle.model}</h2>
                  <p className="text-sm text-muted-foreground mb-3">{vehicle.year}</p>
                  
                  <div className="flex justify-between items-center mb-4 text-sm">
                      <span className="flex items-center text-muted-foreground">
                          <svg className="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6V4m0 16v-2m0-10v2m0 6v2m-6-2h2m10 0h2M6 12H4m16 0h-2m-5.414-5.414l-1.414-1.414M18.364 18.364l-1.414-1.414M5.636 5.636l1.414 1.414m11.314 11.314l1.414 1.414"></path></svg>
                          {vehicle.specifications?.fuelType || 'N/A'}
                      </span>
                      <span className="flex items-center text-muted-foreground">
                          <svg className="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"></path></svg>
                          {vehicle.specifications?.transmission || 'N/A'}
                      </span>
                  </div>

                  <div className="mb-4">
                    <span className="font-bold text-primary text-2xl">{formatPrice(vehicle)}</span>{vehicle.priceIsDemo ? <span className="ml-2 text-xs text-amber-600">Unverified / demo price</span> : vehicle.source && <span className="ml-2 text-xs text-muted-foreground">Source provided · {vehicle.sourceUpdatedAt ? new Date(vehicle.sourceUpdatedAt).toLocaleDateString() : 'date unavailable'}</span>}
                  </div>
                  <div className="flex gap-2">
                    <Button asChild variant="gradient" className="flex-1">
                      <Link to={`/vehicle/${vehicle._id}`}>View Details</Link>
                    </Button>
                    <Button variant="outline" size="icon" aria-label="Add to cart" onClick={() => { addItem(vehicle); toast.success('Added to cart'); }}>
                      <ShoppingCart />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div className="mt-12 flex justify-center items-center space-x-4">
              <button
                onClick={() => handlePageChange(pagination.currentPage - 1)}
                disabled={pagination.currentPage === 1}
                className="px-4 py-2 bg-card border border-input text-foreground/90 rounded-lg hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Previous
              </button>
              <span className="text-foreground font-medium">
                Page {pagination.currentPage} of {pagination.totalPages}
              </span>
              <button
                onClick={() => handlePageChange(pagination.currentPage + 1)}
                disabled={pagination.currentPage === pagination.totalPages}
                className="px-4 py-2 bg-card border border-input text-foreground/90 rounded-lg hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Next
              </button>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-20">
          <h2 className="text-2xl font-semibold text-foreground/90">No Vehicles Found</h2>
          <p className="mt-2 text-muted-foreground">Please try adjusting your filters or check back later.</p>
        </div>
      )}
    </div>
  );
};

export default VehicleListing;