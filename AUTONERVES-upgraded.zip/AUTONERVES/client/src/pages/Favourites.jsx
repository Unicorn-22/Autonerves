import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import favouriteService from '../services/favouriteService';
import toast from 'react-hot-toast';
import { formatPrice } from '@/lib/format';
export default function Favourites() {
  const [items,setItems] = useState([]);
  const [loading,setLoading] = useState(true);
  const load = () => favouriteService.getFavourites().then(setItems).catch(() => toast.error('Unable to load saved cars.')).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);
  const remove = async id => { try { await favouriteService.toggleFavourite(id); setItems(old => old.filter(x => x.car?._id !== id)); } catch { toast.error('Could not remove favourite.'); } };
  return <main className="container mx-auto px-4 py-10"><h1 className="mb-6 text-3xl font-bold">Saved cars</h1>{loading ? <p>Loading…</p> : items.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{items.map(item => item.car && <article key={item._id} className="rounded-xl border bg-card p-4"><h2 className="font-semibold">{item.car.brand} {item.car.model}</h2><p className="text-sm text-muted-foreground">{item.car.year}</p><p className="my-3 font-semibold">{formatPrice(item.car)}</p><div className="flex gap-3"><Link className="text-primary" to={`/vehicle/${item.car._id}`}>View car</Link><button className="text-destructive" onClick={() => remove(item.car._id)}>Remove</button></div></article>)}</div> : <p className="text-muted-foreground">You have not saved any cars yet.</p>}</main>;
}
