import { useEffect, useState } from 'react';
import userService from '../services/userService';
import toast from 'react-hot-toast';

export default function AdminPanel() {
  const [tab,setTab] = useState('dashboard');
  const [loading,setLoading] = useState(true);
  const [users,setUsers] = useState([]);
  const [showrooms,setShowrooms] = useState([]);
  const [summary,setSummary] = useState(null);
  const [activity,setActivity] = useState(null);
  const [adminForm,setAdminForm] = useState({ name:'', email:'', password:'', showroomId:'' });
  const [creating,setCreating] = useState(false);

  const load = async selected => {
    setLoading(true);
    try {
      if (selected === 'dashboard') {
        const [overview,events] = await Promise.all([userService.getDashboardSummary(),userService.getActivityDashboard()]);
        setSummary(overview); setActivity(events);
      } else if (selected === 'users') setUsers(await userService.getAllUsers());
      else setShowrooms(await userService.getAllShowrooms());
    } catch (error) { toast.error(error.response?.data?.message || `Could not load ${selected}.`); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(tab); }, [tab]);

  const createAdmin = async e => {
    e.preventDefault(); setCreating(true);
    try {
      await userService.createShowroomAdmin(adminForm);
      toast.success('Showroom admin created.');
      setAdminForm({ name:'', email:'', password:'', showroomId:'' });
      await load('showrooms');
    } catch (error) { toast.error(error.response?.data?.message || 'Could not create showroom admin.'); }
    finally { setCreating(false); }
  };
  const toggleUser = async user => {
    try {
      const updated = await userService.updateUserStatus(user._id,user.isActive === false);
      setUsers(old => old.map(item => item._id === user._id ? updated : item));
      toast.success(updated.isActive ? 'Account activated.' : 'Account deactivated.');
    } catch (error) { toast.error(error.response?.data?.message || 'Could not update account.'); }
  };

  const tabs = [['dashboard','Overview'],['users','Users'],['showrooms','Showrooms']];
  return <main className="container mx-auto px-4 py-8">
    <h1 className="mb-6 text-3xl font-bold">Super Admin Dashboard</h1>
    <div className="overflow-hidden rounded-xl border bg-card">
      <nav className="flex flex-wrap border-b">{tabs.map(([id,label]) => <button key={id} onClick={() => setTab(id)} className={`px-5 py-3 text-sm ${tab===id?'border-b-2 border-primary font-semibold':'text-muted-foreground'}`}>{label}</button>)}</nav>
      <section className="p-5">
        {loading ? <p className="py-12 text-center text-muted-foreground">Loading dashboard…</p> : <>
          {tab === 'dashboard' && summary && <div className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{[['Customers',summary.customers],['Showrooms',summary.showrooms],['Listed cars',summary.cars],['Car views',summary.views],['Searches',summary.searches],['Enquiries',summary.enquiries]].map(([label,value]) => <div key={label} className="rounded-xl border p-5"><p className="text-sm text-muted-foreground">{label}</p><p className="mt-2 text-3xl font-semibold">{Number(value||0).toLocaleString()}</p></div>)}</div>
            <div><h2 className="mb-3 font-semibold">Daily activity (last 30 days)</h2><div className="flex h-28 items-end gap-1 overflow-x-auto rounded-lg border p-2">{(activity?.daily||[]).map(day => <div key={day._id} title={`${day._id}: ${day.count}`} className="min-w-2 flex-1 rounded-t bg-primary/70" style={{height:`${Math.max(4,Math.min(100,day.count*10))}%`}} />)}</div></div>
            <div><h2 className="mb-3 font-semibold">Showroom performance</h2><div className="overflow-x-auto rounded-lg border"><table className="w-full text-left text-sm"><thead><tr className="border-b text-muted-foreground"><th className="p-3">Showroom</th><th className="p-3">Views</th><th className="p-3">Searches</th><th className="p-3">Enquiries</th></tr></thead><tbody>{(activity?.showroomPerformance||[]).map(item=><tr key={item._id} className="border-b"><td className="p-3">{item.name}</td><td className="p-3">{item.views}</td><td className="p-3">{item.searches}</td><td className="p-3">{item.enquiries}</td></tr>)}</tbody></table></div></div>
            <div><h2 className="mb-3 font-semibold">Popular brands</h2><div className="flex flex-wrap gap-2">{(summary.popularBrands||[]).map(item => <span key={item._id} className="rounded-full border px-3 py-1 text-sm">{item._id} · {item.count}</span>)}</div></div>
            <div><h2 className="mb-3 font-semibold">Most viewed models</h2><div className="overflow-x-auto rounded-lg border"><table className="w-full text-left text-sm"><thead><tr className="border-b text-muted-foreground"><th className="p-3">Vehicle</th><th className="p-3">Views</th></tr></thead><tbody>{(activity?.popularCars||[]).map(item=><tr key={item._id} className="border-b"><td className="p-3">{item.brand} {item.model}</td><td className="p-3">{item.views}</td></tr>)}</tbody></table></div></div>
            <div><h2 className="mb-3 font-semibold">Recent activity</h2><div className="space-y-2">{(activity?.recent||[]).slice(0,8).map(item=><div key={item._id} className="rounded-lg border p-3 text-sm"><span className="capitalize">{item.eventType.replaceAll('_',' ')}</span><span className="ml-2 text-muted-foreground">{item.car ? `${item.car.brand} ${item.car.model}` : item.showroom?.name || ''}</span><p className="text-xs text-muted-foreground">{new Date(item.createdAt).toLocaleString()}</p></div>)}</div></div>
          </div>}
          {tab === 'users' && <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead><tr className="border-b text-muted-foreground"><th className="p-3">Name</th><th className="p-3">Email</th><th className="p-3">Role</th><th className="p-3">Status</th><th className="p-3">Action</th></tr></thead><tbody>{users.map(user => <tr key={user._id} className="border-b"><td className="p-3">{user.name}</td><td className="p-3">{user.email}</td><td className="p-3 capitalize">{user.role}</td><td className="p-3">{user.isActive === false ? 'Inactive' : 'Active'}</td><td className="p-3"><button onClick={() => toggleUser(user)} className="text-primary">{user.isActive === false ? 'Activate' : 'Deactivate'}</button></td></tr>)}</tbody></table></div>}
          {tab === 'showrooms' && <div className="space-y-6">
            <form onSubmit={createAdmin} className="grid gap-3 rounded-xl border p-4 md:grid-cols-2">
              <h2 className="font-semibold md:col-span-2">Create showroom admin account</h2>
              <input required placeholder="Admin name" value={adminForm.name} onChange={e=>setAdminForm(v=>({...v,name:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
              <input required type="email" placeholder="Email" value={adminForm.email} onChange={e=>setAdminForm(v=>({...v,email:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
              <input required minLength={8} type="password" placeholder="Temporary password (8+ characters)" value={adminForm.password} onChange={e=>setAdminForm(v=>({...v,password:e.target.value}))} className="rounded-md border bg-background px-3 py-2" />
              <select required value={adminForm.showroomId} onChange={e=>setAdminForm(v=>({...v,showroomId:e.target.value}))} className="rounded-md border bg-background px-3 py-2"><option value="">Assign showroom</option>{showrooms.map(item=><option key={item._id} value={item._id}>{item.name}</option>)}</select>
              <button disabled={creating} className="rounded-md bg-primary px-4 py-2 text-primary-foreground md:col-span-2">{creating?'Creating…':'Create showroom admin'}</button>
            </form>
            <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead><tr className="border-b text-muted-foreground"><th className="p-3">Showroom</th><th className="p-3">Address</th><th className="p-3">Assigned admin</th><th className="p-3">Status</th></tr></thead><tbody>{showrooms.map(item=><tr key={item._id} className="border-b"><td className="p-3">{item.name}</td><td className="p-3">{[item.address,item.city,item.state].filter(Boolean).join(', ')}</td><td className="p-3">{item.owner?.name || 'Not assigned'}</td><td className="p-3">{item.isActive === false ? 'Inactive' : 'Active'}</td></tr>)}</tbody></table></div>
          </div>}
        </>}
      </section>
    </div>
  </main>;
}
