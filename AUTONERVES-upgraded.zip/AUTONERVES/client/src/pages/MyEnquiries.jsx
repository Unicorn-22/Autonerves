import { useEffect, useState } from 'react';
import enquiryService from '../services/enquiryService';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
export default function MyEnquiries() {
  const [items,setItems] = useState([]);
  const [loading,setLoading] = useState(true);
  useEffect(() => { enquiryService.getMyEnquiries().then(setItems).catch(() => toast.error('Unable to load your enquiries.')).finally(() => setLoading(false)); }, []);
  return <main className="container mx-auto px-4 py-10"><h1 className="mb-6 text-3xl font-bold">My enquiries</h1>{loading ? <p>Loading…</p> : items.length ? <div className="space-y-3">{items.map(item => <article key={item._id} className="rounded-xl border bg-card p-4"><p className="font-semibold">{item.car?.brand} {item.car?.model}</p><p className="text-sm text-muted-foreground">{item.showroom?.name} · {new Date(item.createdAt).toLocaleString()}</p><p className="mt-2 text-sm">Status: <strong className="capitalize">{item.status}</strong></p><Link className="mt-2 inline-block text-sm text-primary" to={`/vehicle/${item.car?._id}`}>View car</Link></article>)}</div> : <p className="text-muted-foreground">No enquiries submitted yet.</p>}</main>;
}
