import { useEffect, useMemo, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Link } from 'react-router-dom';
import showroomService from '../services/showroomService';
import toast from 'react-hot-toast';
import 'leaflet/dist/leaflet.css';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png'
});
const INDIA_CENTER = [20.5937, 78.9629];
function MapFocus({ position }) {
  const map = useMap();
  useEffect(() => { if (position) map.flyTo(position, 12); }, [position, map]);
  return null;
}
const validCoordinates = (showroom) => {
  if (showroom?.isDemo) return false;
  const c = showroom?.location?.coordinates;
  return Array.isArray(c) && c.length === 2 && c.every(Number.isFinite) &&
    Math.abs(c[1]) <= 90 && Math.abs(c[0]) <= 180 && !(c[0] === 0 && c[1] === 0);
};
export default function ShowroomLocator() {
  const [showrooms, setShowrooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [city, setCity] = useState('');
  const [position, setPosition] = useState(null);
  const [selected, setSelected] = useState(null);
  const [cars, setCars] = useState([]);
  const load = async (searchCity = city) => {
    setLoading(true);
    try {
      const result = await showroomService.getAllShowrooms(1, 100, searchCity);
      setShowrooms(Array.isArray(result) ? result : result.showrooms || []);
    } catch (error) {
      setShowrooms([]);
      toast.error('Could not load showroom locations from the server.');
    } finally { setLoading(false); }
  };
  useEffect(() => { load(''); }, []);
  useEffect(() => {
    if (!selected?._id) { setCars([]); return; }
    showroomService.getShowroomVehicles(selected._id, 1, 6)
      .then(result => setCars(result.vehicles || []))
      .catch(() => setCars([]));
  }, [selected]);
  const mapped = useMemo(() => showrooms.filter(validCoordinates), [showrooms]);
  const useMyLocation = () => {
    if (!navigator.geolocation) return toast.error('Geolocation is not supported by this browser.');
    navigator.geolocation.getCurrentPosition(
      async p => {
        const lat = p.coords.latitude, lng = p.coords.longitude;
        setPosition([lat,lng]);
        setLoading(true);
        try { setShowrooms(await showroomService.getShowrooms({ lat, lng, distance: 25 })); }
        catch { toast.error('Could not load nearby showrooms.'); }
        finally { setLoading(false); }
      },
      () => toast.error('Location permission was not granted. You can still search by city.'),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };
  const center = position || (selected && validCoordinates(selected)
    ? [selected.location.coordinates[1], selected.location.coordinates[0]] : INDIA_CENTER);
  return <main className="container mx-auto px-4 py-8">
    <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div><h1 className="text-3xl font-bold">Showroom locations</h1><p className="mt-1 text-muted-foreground">Verified coordinates are shown on the map. Locations without coordinates remain listed without a marker.</p></div>
      <div className="flex flex-wrap gap-2">
        <input value={city} onChange={e => setCity(e.target.value)} onKeyDown={e => e.key === 'Enter' && load()} placeholder="Search city or state" className="rounded-md border bg-background px-3 py-2" />
        <button onClick={() => load()} className="rounded-md bg-primary px-4 py-2 text-primary-foreground">Search</button>
        <button onClick={useMyLocation} className="rounded-md border px-4 py-2">Use my location</button>
      </div>
    </div>
    <div className="grid gap-6 lg:grid-cols-[minmax(280px,0.8fr)_1.5fr]">
      <section className="space-y-3">
        <p className="text-sm text-muted-foreground">{loading ? 'Loading showrooms…' : `${showrooms.length} showroom(s) · ${mapped.length} mapped`}</p>
        {!loading && showrooms.length === 0 && <div className="rounded-xl border p-6 text-muted-foreground">No showrooms match this search.</div>}
        {showrooms.map(s => <button key={s._id} onClick={() => { setSelected(s); if (validCoordinates(s)) setPosition([s.location.coordinates[1], s.location.coordinates[0]]); }} className={`w-full rounded-xl border p-4 text-left transition hover:border-primary ${selected?._id === s._id ? 'border-primary bg-primary/5' : ''}`}>
          <div className="flex items-center justify-between gap-2"><strong>{s.name}</strong><span className="text-xs text-muted-foreground">{s.isDemo ? 'Demo record · unverified' : validCoordinates(s) ? 'Mapped' : 'Location unavailable'}</span></div>
          <p className="mt-1 text-sm text-muted-foreground">{[s.address,s.city,s.state,s.postalCode].filter(Boolean).join(', ')}</p>
          <p className="mt-2 text-sm">{s.phone || 'Contact not provided'} · {s.hours || 'Hours not provided'}</p>
        </button>)}
      </section>
      <section className="min-h-[480px] overflow-hidden rounded-xl border">
        <MapContainer center={center} zoom={5} style={{ height: '600px', width: '100%' }} scrollWheelZoom>
          <MapFocus position={position || (selected && validCoordinates(selected) ? [selected.location.coordinates[1], selected.location.coordinates[0]] : null)} />
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' />
          {mapped.map(s => <Marker key={s._id} position={[s.location.coordinates[1],s.location.coordinates[0]]} eventHandlers={{ click: () => setSelected(s) }}>
            <Popup><strong>{s.name}</strong><br />{[s.address,s.city,s.state].filter(Boolean).join(', ')}<br /><a href={`https://www.openstreetmap.org/directions?to=${s.location.coordinates[1]}%2C${s.location.coordinates[0]}`} target="_blank" rel="noreferrer">Directions</a></Popup>
          </Marker>)}
        </MapContainer>
        {selected && <div className="border-t bg-card p-4"><div className="flex items-start justify-between"><div><h2 className="font-semibold">{selected.name}</h2><p className="text-sm text-muted-foreground">{[selected.address,selected.city,selected.state].filter(Boolean).join(', ')}</p></div><Link className="text-sm text-primary" to={`/showroom/${selected._id}`}>Showroom details</Link></div>
          <p className="mt-3 font-medium">Available vehicles</p>{cars.length ? <div className="mt-2 flex flex-wrap gap-2">{cars.map(c => <Link key={c._id} to={`/vehicle/${c._id}`} className="rounded-md border px-3 py-1 text-sm">{c.brand} {c.model}</Link>)}</div> : <p className="text-sm text-muted-foreground">No listed cars found.</p>}
        </div>}
      </section>
    </div>
  </main>;
}
