import { useState, useEffect, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { formatPrice } from '@/lib/format';
import { AuthContext } from "../contexts/AuthContext";
import showroomService from "../services/showroomService";
import vehicleService from "../services/vehicleService";
import toast from "react-hot-toast";
import activityService from "../services/activityService";

const ShowroomManagement = () => {
  const { user, isAuthenticated } = useContext(AuthContext);
  const navigate = useNavigate();

  const [showrooms, setShowrooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("showrooms");
  const [selectedShowroom, setSelectedShowroom] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [vehiclesLoading, setVehiclesLoading] = useState(false);
  const [analytics, setAnalytics] = useState(null);

  useEffect(() => {
    if (user?.role === "dealer") activityService.getDashboard().then(setAnalytics).catch(() => setAnalytics(null));
  }, [user]);

  // New showroom form state
  const [showroomForm, setShowroomForm] = useState({
    name: "",
    address: "",
    city: "",
    state: "",
    phone: "",
    email: "",
    vehicleTypes: [],
    lat: "",
    lng: "",
    description: "",
  });

  // New vehicle form state
  const [vehicleForm, setVehicleForm] = useState({
    type: "car",
    brand: "",
    model: "",
    variant: "",
    bodyType: "",
    source: "",
    sourceUpdatedAt: "",
    year: new Date().getFullYear(),
    price: "",
    description: "",
    specifications: {
      engine: "",
      transmission: "",
      mileage: "",
      fuelType: "",
      seatingCapacity: "",
      colors: "",
      features: "",
    },
    showroom: "",
  });
  const [vehicleImages, setVehicleImages] = useState(null);

  const handleImageChange = (e) => {
    setVehicleImages(e.target.files);
  };

  // Check if user is authorized
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login", { state: { from: { pathname: "/manage-showroom" } } });
      return;
    }

    if (user && user.role !== "dealer" && user.role !== "admin") {
      toast.error("Only dealers can access this page");
      navigate("/");
      return;
    }

    // Load dealer showrooms
    const loadShowrooms = async () => {
      try {
        setLoading(true);
        // This would be a custom endpoint in a real app to get showrooms owned by the dealer
        const response = await showroomService.getAllShowrooms();
        // Filter by owner (this would be done on the backend in a real app)
        const filteredShowrooms = response.showrooms.filter(
          (showroom) => showroom.owner && showroom.owner.id === user.id
        );
        setShowrooms(filteredShowrooms);
      } catch (error) {
        console.error("Error loading showrooms:", error);
        toast.error("Failed to load showrooms");
      } finally {
        setLoading(false);
      }
    };

    loadShowrooms();
  }, [isAuthenticated, user, navigate]);

  // Load vehicles for selected showroom
  useEffect(() => {
    if (selectedShowroom) {
      const loadVehicles = async () => {
        try {
          setVehiclesLoading(true);
          const data = await showroomService.getShowroomVehicles(
            selectedShowroom._id
          );
          setVehicles(data.vehicles);
        } catch (error) {
          console.error("Error loading vehicles:", error);
          toast.error("Failed to load vehicles");
        } finally {
          setVehiclesLoading(false);
        }
      };

      loadVehicles();
    }
  }, [selectedShowroom]);

  const handleShowroomFormChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (name === "vehicleTypes") {
      // Handle checkbox array
      const updatedVehicleTypes = [...showroomForm.vehicleTypes];
      if (checked) {
        updatedVehicleTypes.push(value);
      } else {
        const index = updatedVehicleTypes.indexOf(value);
        if (index > -1) {
          updatedVehicleTypes.splice(index, 1);
        }
      }

      setShowroomForm({
        ...showroomForm,
        vehicleTypes: updatedVehicleTypes,
      });
    } else {
      setShowroomForm({
        ...showroomForm,
        [name]: value,
      });
    }
  };

  const handleVehicleFormChange = (e) => {
    const { name, value } = e.target;

    // Handle nested specifications
    if (name.startsWith("spec_")) {
      const specName = name.replace("spec_", "");
      setVehicleForm({
        ...vehicleForm,
        specifications: {
          ...vehicleForm.specifications,
          [specName]: value,
        },
      });
    } else {
      setVehicleForm({
        ...vehicleForm,
        [name]: value,
      });
    }
  };

  const handleShowroomSubmit = async (e) => {
    e.preventDefault();

    try {
      // Prepare data
      const showroomData = { ...showroomForm };
      if (showroomForm.lat !== "" && showroomForm.lng !== "") {
        const lat = Number(showroomForm.lat), lng = Number(showroomForm.lng);
        if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
          toast.error("Enter valid latitude and longitude.");
          return;
        }
        showroomData.location = { type: "Point", coordinates: [lng, lat] };
      }
      delete showroomData.lat;
      delete showroomData.lng;

      const newShowroom = await showroomService.createShowroom(showroomData);

      setShowrooms([...showrooms, newShowroom]);
      setShowroomForm({
        name: "",
        address: "",
        city: "",
        state: "",
        phone: "",
        email: "",
        vehicleTypes: [],
        lat: "",
        lng: "",
        description: "",
      });

      toast.success("Showroom created successfully!");
      setActiveTab("showrooms");
    } catch (error) {
      console.error("Error creating showroom:", error);
      toast.error(error.response?.data?.message || "Failed to create showroom");
    }
  };

  const handleVehicleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Step 1: Create vehicle with text data
      const processedForm = {
        ...vehicleForm,
        specifications: {
          ...vehicleForm.specifications,
          colors: vehicleForm.specifications.colors.split(",").map((color) => color.trim()),
          features: vehicleForm.specifications.features.split(",").map((feature) => feature.trim()),
        },
        showroom: selectedShowroom._id,
      };

      const newVehicle = await vehicleService.createVehicle(processedForm);

      // Step 2: If there are images, upload them
      if (vehicleImages && vehicleImages.length > 0) {
        const imageFormData = new FormData();
        for (let i = 0; i < vehicleImages.length; i++) {
          imageFormData.append('images', vehicleImages[i]);
        }
        
        const updatedVehicle = await vehicleService.uploadVehicleImages(newVehicle._id, imageFormData);
        setVehicles([updatedVehicle, ...vehicles]);
      } else {
        setVehicles([newVehicle, ...vehicles]);
      }

      // Reset form
      setVehicleForm({
        type: "car",
        brand: "",
        model: "",
        year: new Date().getFullYear(),
        price: "",
        description: "",
        specifications: {
          engine: "",
          transmission: "",
          mileage: "",
          fuelType: "",
          seatingCapacity: "",
          colors: "",
          features: "",
        },
        showroom: selectedShowroom._id,
      });
      setVehicleImages(null);
      // This is a bit of a hack to clear the file input visually
      document.querySelector('input[type="file"][name="images"]').value = "";

      toast.success("Vehicle added successfully!");
    } catch (error) {
      console.error("Error adding vehicle:", error);
      toast.error(error.response?.data?.message || "Failed to add vehicle");
    }
  };

  const handleDeleteShowroom = async (showroomId) => {
    if (
      !window.confirm(
        "Are you sure you want to delete this showroom? This will also delete all vehicles associated with it."
      )
    ) {
      return;
    }

    try {
      await showroomService.deleteShowroom(showroomId);
      setShowrooms(showrooms.filter((showroom) => showroom._id !== showroomId));

      if (selectedShowroom && selectedShowroom._id === showroomId) {
        setSelectedShowroom(null);
        setVehicles([]);
      }

      toast.success("Showroom deleted successfully");
    } catch (error) {
      console.error("Error deleting showroom:", error);
      toast.error("Failed to delete showroom");
    }
  };

  const handleDeleteVehicle = async (vehicleId) => {
    if (!window.confirm("Are you sure you want to delete this vehicle?")) {
      return;
    }

    try {
      await vehicleService.deleteVehicle(vehicleId);
      setVehicles(vehicles.filter((vehicle) => vehicle._id !== vehicleId));

      toast.success("Vehicle deleted successfully");
    } catch (error) {
      console.error("Error deleting vehicle:", error);
      toast.error("Failed to delete vehicle");
    }
  };

  if (
    !isAuthenticated ||
    (user && user.role !== "dealer" && user.role !== "admin")
  ) {
    return null; // This is handled in useEffect
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Showroom Management</h1>
      {analytics && <section className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[["Car views",analytics.totals?.carViews],["Searches",analytics.totals?.searches],["Enquiries",analytics.totals?.enquiries],["Comparisons",analytics.totals?.comparisons]].map(([label,value]) => <div key={label} className="rounded-xl border bg-card p-4"><p className="text-sm text-muted-foreground">{label}</p><p className="text-2xl font-semibold">{Number(value || 0).toLocaleString()}</p></div>)}
      </section>}
      {analytics && <section className="mb-6 grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border bg-card p-4"><h2 className="mb-3 font-semibold">Most viewed cars</h2>{analytics.popularCars?.length ? analytics.popularCars.map(car => <div key={car._id} className="flex justify-between border-b py-2 text-sm"><span>{car.brand} {car.model}</span><strong>{car.views} views</strong></div>) : <p className="text-sm text-muted-foreground">No car views recorded yet.</p>}</div>
        <div className="rounded-xl border bg-card p-4"><h2 className="mb-3 font-semibold">Recent interactions</h2>{analytics.recent?.length ? analytics.recent.slice(0,6).map(item => <div key={item._id} className="border-b py-2 text-sm"><span className="capitalize">{item.eventType.replaceAll('_',' ')}</span><span className="ml-2 text-muted-foreground">{item.car ? `${item.car.brand} ${item.car.model}` : item.showroom?.name || ''}</span><p className="text-xs text-muted-foreground">{new Date(item.createdAt).toLocaleString()}</p></div>) : <p className="text-sm text-muted-foreground">No recent interactions yet.</p>}</div>
      </section>}

      <div className="bg-card shadow-md rounded-lg overflow-hidden">
        {/* Tabs */}
        <div className="flex border-b">
          <button
            className={`px-4 py-3 ${
              activeTab === "showrooms"
                ? "bg-primary/10 border-b-2 border-primary font-medium"
                : "text-muted-foreground hover:text-foreground"
            }`}
            onClick={() => setActiveTab("showrooms")}
          >
            My Showrooms
          </button>
          {user?.role === "admin" && <button
            className={`px-4 py-3 ${
              activeTab === "add-showroom"
                ? "bg-primary/10 border-b-2 border-primary font-medium"
                : "text-muted-foreground hover:text-foreground"
            }`}
            onClick={() => setActiveTab("add-showroom")}
          >
            Add New Showroom
          </button>}
          {selectedShowroom && (
            <button
              className={`px-4 py-3 ${
                activeTab === "add-vehicle"
                  ? "bg-primary/10 border-b-2 border-primary font-medium"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              onClick={() => setActiveTab("add-vehicle")}
            >
              Add Vehicle to {selectedShowroom.name}
            </button>
          )}
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {/* My Showrooms Tab */}
          {activeTab === "showrooms" && (
            <div>
              <h2 className="text-xl font-semibold mb-4">My Showrooms</h2>

              {loading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : showrooms.length > 0 ? (
                <div className="space-y-4">
                  {showrooms.map((showroom) => (
                    <div key={showroom._id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-medium">
                            {showroom.name}
                          </h3>
                          <p className="text-muted-foreground">
                            {showroom.address}, {showroom.city},{" "}
                            {showroom.state}
                          </p>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {showroom.vehicleTypes.map((type) => (
                              <span
                                key={type}
                                className="bg-secondary text-foreground text-xs px-2 py-1 rounded"
                              >
                                {type.charAt(0).toUpperCase() + type.slice(1)}s
                              </span>
                            ))}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setSelectedShowroom(showroom);
                              setActiveTab("add-vehicle");
                            }}
                            className="bg-emerald-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600"
                          >
                            Add Vehicle
                          </button>
                          {user?.role === "admin" && <button onClick={() => handleToggleShowroom(showroom)} className="rounded bg-secondary px-3 py-1 text-sm">{showroom.isActive === false ? "Activate" : "Deactivate"}</button>}
                          {user?.role === "admin" && <button
                            onClick={() => handleDeleteShowroom(showroom._id)}
                            className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
                          >
                            Delete
                          </button>}
                        </div>
                      </div>

                      <button
                        onClick={() => setSelectedShowroom(showroom)}
                        className="mt-3 text-primary hover:text-primary text-sm font-medium"
                      >
                        Manage Vehicles ({showroom.vehicleCount || "0"})
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">
                    You don't have any showrooms yet.
                  </p>
                  <button
                    onClick={() => setActiveTab("add-showroom")}
                    className="bg-primary text-white px-4 py-2 rounded hover:bg-primary"
                  >
                    Add Your First Showroom
                  </button>
                </div>
              )}

              {/* Vehicle Listing for Selected Showroom */}
              {selectedShowroom && (
                <div className="mt-8">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold">
                      Vehicles at {selectedShowroom.name}
                    </h3>
                    <button
                      onClick={() => setSelectedShowroom(null)}
                      className="text-muted-foreground hover:text-foreground/90"
                    >
                      Close
                    </button>
                  </div>

                  {vehiclesLoading ? (
                    <div className="flex justify-center py-4">
                      <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                    </div>
                  ) : vehicles.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-border">
                        <thead className="bg-muted/50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                              Vehicle
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                              Type
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                              Price
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                              Status
                            </th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-card divide-y divide-border">
                          {vehicles.map((vehicle) => (
                            <tr key={vehicle._id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="font-medium text-foreground">
                                  {vehicle.brand} {vehicle.model}
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  {vehicle.year}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                                {vehicle.type.charAt(0).toUpperCase() +
                                  vehicle.type.slice(1)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">
                                {formatPrice(vehicle)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span
                                  className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                    vehicle.available
                                      ? "bg-emerald-500/15 text-emerald-400"
                                      : "bg-destructive/15 text-red-400"
                                  }`}
                                >
                                  {vehicle.available ? "Available" : "Sold"}
                                </span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <a
                                  href={`/vehicle/${vehicle._id}`}
                                  className="text-primary hover:text-primary/80 mr-3"
                                >
                                  View
                                </a>
                                <button
                                  onClick={() =>
                                    handleDeleteVehicle(vehicle._id)
                                  }
                                  className="text-red-400 hover:text-red-300"
                                >
                                  Delete
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-muted-foreground">
                        No vehicles available for this showroom.
                      </p>
                      <button
                        onClick={() => setActiveTab("add-vehicle")}
                        className="mt-2 text-primary hover:text-primary text-sm font-medium"
                      >
                        Add Your First Vehicle
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Add Showroom Tab */}
          {activeTab === "add-showroom" && (
            <div>
              <h2 className="text-xl font-semibold mb-4">Add New Showroom</h2>

              <form onSubmit={handleShowroomSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Showroom Name*
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={showroomForm.name}
                      onChange={handleShowroomFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Email*
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={showroomForm.email}
                      onChange={handleShowroomFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Phone*
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={showroomForm.phone}
                      onChange={handleShowroomFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Vehicle Types*
                    </label>
                    <div className="flex space-x-4">
                      <label className="inline-flex items-center">
                        <input
                          type="checkbox"
                          name="vehicleTypes"
                          value="car"
                          checked={showroomForm.vehicleTypes.includes("car")}
                          onChange={handleShowroomFormChange}
                          className="h-4 w-4 text-primary focus:ring-ring"
                        />
                        <span className="ml-2">Cars</span>
                      </label>
                      <label className="inline-flex items-center">
                        <input
                          type="checkbox"
                          name="vehicleTypes"
                          value="bike"
                          checked={showroomForm.vehicleTypes.includes("bike")}
                          onChange={handleShowroomFormChange}
                          className="h-4 w-4 text-primary focus:ring-ring"
                        />
                        <span className="ml-2">Bikes</span>
                      </label>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground/90 mb-1">
                    Address*
                  </label>
                  <input
                    type="text"
                    name="address"
                    value={showroomForm.address}
                    onChange={handleShowroomFormChange}
                    required
                    className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      City*
                    </label>
                    <input
                      type="text"
                      name="city"
                      value={showroomForm.city}
                      onChange={handleShowroomFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      State*
                    </label>
                    <input
                      type="text"
                      name="state"
                      value={showroomForm.state}
                      onChange={handleShowroomFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Latitude* (e.g., 28.7041)
                    </label>
                    <input
                      type="text"
                      name="lat"
                      value={showroomForm.lat}
                      onChange={handleShowroomFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Longitude* (e.g., 77.1025)
                    </label>
                    <input
                      type="text"
                      name="lng"
                      value={showroomForm.lng}
                      onChange={handleShowroomFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground/90 mb-1">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={showroomForm.description}
                    onChange={handleShowroomFormChange}
                    rows="4"
                    className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                  ></textarea>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition"
                  >
                    Create Showroom
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Add Vehicle Tab */}
          {activeTab === "add-vehicle" && selectedShowroom && (
            <div>
              <h2 className="text-xl font-semibold mb-4">
                Add Vehicle to {selectedShowroom.name}
              </h2>

              <form onSubmit={handleVehicleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Vehicle Type*
                    </label>
                    <select
                      name="type"
                      value={vehicleForm.type}
                      onChange={handleVehicleFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      {selectedShowroom.vehicleTypes.includes("car") && (
                        <option value="car">Car</option>
                      )}
                      {selectedShowroom.vehicleTypes.includes("bike") && (
                        <option value="bike">Bike</option>
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Brand*
                    </label>
                    <input
                      type="text"
                      name="brand"
                      value={vehicleForm.brand}
                      onChange={handleVehicleFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Model*
                    </label>
                    <input
                      type="text"
                      name="model"
                      value={vehicleForm.model}
                      onChange={handleVehicleFormChange}
                      required
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div><label className="block text-sm font-medium mb-1">Variant</label><input name="variant" value={vehicleForm.variant} onChange={handleVehicleFormChange} className="w-full rounded border border-input bg-background p-2" placeholder="e.g. ZXi / SX(O)" /></div>
                  <div><label className="block text-sm font-medium mb-1">Body type</label><input name="bodyType" value={vehicleForm.bodyType} onChange={handleVehicleFormChange} className="w-full rounded border border-input bg-background p-2" placeholder="SUV / Sedan / Hatchback" /></div>
                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">Year*</label>
                    <input
                      type="number"
                      name="year"
                      value={vehicleForm.year}
                      onChange={handleVehicleFormChange}
                      required
                      min="1900"
                      max={new Date().getFullYear() + 1}
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Price (₹)*
                    </label>
                    <input
                      type="number"
                      name="price"
                      value={vehicleForm.price}
                      onChange={handleVehicleFormChange}
                      required
                      min="0"
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div><label className="block text-sm font-medium mb-1">Price source (URL or document reference)</label><input name="source" value={vehicleForm.source} onChange={handleVehicleFormChange} className="w-full rounded border border-input bg-background p-2" placeholder="Source URL / dealer quotation reference" /></div>
                  <div><label className="block text-sm font-medium mb-1">Source updated date</label><input type="date" name="sourceUpdatedAt" value={vehicleForm.sourceUpdatedAt} onChange={handleVehicleFormChange} className="w-full rounded border border-input bg-background p-2" /></div>
                </div>
                <p className="text-xs text-muted-foreground">Without a source and update date, the price remains labelled as unverified/demo. Providing a source does not mean AUTONERVES independently verifies it.</p>

                <div>
                  <label className="block text-sm font-medium text-foreground/90 mb-1">
                    Images (up to 5)
                  </label>
                  <input
                    type="file"
                    name="images"
                    multiple
                    onChange={handleImageChange}
                    accept="image/png, image/jpeg, image/gif"
                    className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground/90 mb-1">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={vehicleForm.description}
                    onChange={handleVehicleFormChange}
                    rows="3"
                    className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                  ></textarea>
                </div>

                <h3 className="text-lg font-medium mt-6">Specifications</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Engine
                    </label>
                    <input
                      type="text"
                      name="spec_engine"
                      value={vehicleForm.specifications.engine}
                      onChange={handleVehicleFormChange}
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Transmission
                    </label>
                    <input
                      type="text"
                      name="spec_transmission"
                      value={vehicleForm.specifications.transmission}
                      onChange={handleVehicleFormChange}
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Mileage
                    </label>
                    <input
                      type="text"
                      name="spec_mileage"
                      value={vehicleForm.specifications.mileage}
                      onChange={handleVehicleFormChange}
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Fuel Type
                    </label>
                    <input
                      type="text"
                      name="spec_fuelType"
                      value={vehicleForm.specifications.fuelType}
                      onChange={handleVehicleFormChange}
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground/90 mb-1">
                      Seating Capacity
                    </label>
                    <input
                      type="number"
                      name="spec_seatingCapacity"
                      value={vehicleForm.specifications.seatingCapacity}
                      onChange={handleVehicleFormChange}
                      min="1"
                      className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground/90 mb-1">
                    Available Colors (comma separated)
                  </label>
                  <input
                    type="text"
                    name="spec_colors"
                    value={vehicleForm.specifications.colors}
                    onChange={handleVehicleFormChange}
                    placeholder="Red, Blue, Black, White"
                    className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground/90 mb-1">
                    Features (comma separated)
                  </label>
                  <input
                    type="text"
                    name="spec_features"
                    value={vehicleForm.specifications.features}
                    onChange={handleVehicleFormChange}
                    placeholder="ABS, Power Steering, AC, GPS Navigation"
                    className="w-full p-2 border border-input rounded focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition"
                  >
                    Add Vehicle
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ShowroomManagement;
