import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { AuthProvider } from "./contexts/AuthContext";
import { useEffect } from "react";
// Layouts
import MainLayout from "./layouts/MainLayout";
// Pages
import Home from "./pages/Home";
import Registration from "./pages/Registration";
import Login from "./pages/Login";
import VehicleListing from "./pages/VehicleListing";
import ShowroomLocator from "./pages/ShowroomLocator";
import VehicleComparison from "./pages/VehicleComparison";
import ShowroomManagement from "./pages/ShowroomManagement";
import VehicleDetails from "./pages/VehicleDetails";
import ShowroomDetails from "./pages/ShowroomDetails";
// import VehicleListing from './pages/VehicleListing';
import NotFound from "./pages/NotFound";
import AuthCallback from "./pages/AuthCallback";
import AdminPanel from "./pages/AdminPanel";
import Favourites from "./pages/Favourites";
import MyEnquiries from "./pages/MyEnquiries";
import EnquiryManagement from "./pages/EnquiryManagement";
// Components
import ProtectedRoute from "./components/ProtectedRoute";
import { ComparisonProvider } from "./contexts/ComparisonContext";
import { ImageSourceProvider } from "./contexts/ImageSourceContext";
import { CartProvider } from "./contexts/CartContext";

function App() {
  useEffect(() => {
    if (window.AOS) {
      window.AOS.init({
        duration: 1000,
        once: true,
      });
    }
  }, []);

  return (
    <AuthProvider>
      <ComparisonProvider>
        <CartProvider>
<ImageSourceProvider>
          <Router>
            <Toaster position="top-right" toastOptions={{ style: { background: "hsl(221 39% 9%)", color: "#fff", border: "1px solid hsl(215 28% 17%)" } }} />
            <Routes>
              <Route path="/" element={<MainLayout />}>
                <Route index element={<Home />} />
                <Route path="register" element={<Registration />} />
                <Route path="login" element={<Login />} />

                <Route path="vehicles" element={<VehicleListing />} />
                <Route path="showrooms" element={<ShowroomLocator />} />
                <Route
                  path="compare"
                  element={
                    <ProtectedRoute redirectTo="/register">
                      <VehicleComparison />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="manage-showroom"
                  element={
                    <ProtectedRoute requiredRole="dealer">
                      <ShowroomManagement />
                    </ProtectedRoute>
                  }
                />
                <Route path="vehicle/:id" element={<VehicleDetails />} />
                <Route path="favourites" element={<ProtectedRoute redirectTo="/login"><Favourites /></ProtectedRoute>} />
                <Route path="my-enquiries" element={<ProtectedRoute redirectTo="/login"><MyEnquiries /></ProtectedRoute>} />
                <Route path="manage-enquiries" element={<ProtectedRoute requiredRole="dealer"><EnquiryManagement /></ProtectedRoute>} />
                <Route path="showroom/:id" element={<ShowroomDetails />} />
                <Route path="auth/callback" element={<AuthCallback />} />
                <Route
                  path="admin"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <AdminPanel />
                    </ProtectedRoute>
                  }
                />
                <Route path="*" element={<NotFound />} />
              </Route>
            </Routes>
          </Router>
        </ImageSourceProvider>
</CartProvider>
      </ComparisonProvider>
    </AuthProvider>
  );
}

export default App;
