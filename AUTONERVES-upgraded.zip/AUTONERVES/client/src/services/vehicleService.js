// client/src/services/vehicleService.js
import axios from 'axios';

const API_URL = `${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}/vehicles`;

// Create axios instance with auth token
const axiosInstance = axios.create({
  baseURL: API_URL
});

// Add token to requests
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['x-auth-token'] = token;
    }
    const consent = localStorage.getItem('autonerves_analytics_consent') || 'no';
    config.headers['x-analytics-consent'] = consent;
    if (consent === 'yes') {
      let sid = localStorage.getItem('autonerves_session');
      if (!sid) { sid = globalThis.crypto?.randomUUID?.() || `session-${Date.now()}-${Math.random().toString(36).slice(2)}`; localStorage.setItem('autonerves_session', sid); }
      config.headers['x-session-id'] = sid;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Get all vehicles with pagination
const getAllVehicles = async (params = {}) => {
  const queryParams = new URLSearchParams(params);
  const response = await axiosInstance.get(`?${queryParams.toString()}`);
  return response.data;
};

// Get vehicle by ID
const getVehicleById = async (id) => {
  const response = await axiosInstance.get(`/${id}`);
  return response.data;
};

// Search vehicles
const searchVehicles = async (searchParams) => {
  // Convert search params to query string
  const queryParams = new URLSearchParams();
  
  for (const key in searchParams) {
    if (searchParams[key] !== undefined && searchParams[key] !== '') {
      if (key === 'userLocation' && searchParams[key]) {
        queryParams.append('lat', searchParams[key].lat);
        queryParams.append('lng', searchParams[key].lng);
      } else if (key === 'priceRange' && Array.isArray(searchParams[key])) {
        queryParams.append('minPrice', searchParams[key][0]);
        queryParams.append('maxPrice', searchParams[key][1]);
      } else {
        queryParams.append(key, searchParams[key]);
      }
    }
  }
  
  const response = await axiosInstance.get(`/search?${queryParams.toString()}`);
  return response.data;
};

// Create new vehicle
const createVehicle = async (vehicleData) => {
  const response = await axiosInstance.post('/', vehicleData);
  return response.data;
};

// Update vehicle
const updateVehicle = async (id, vehicleData) => {
  const response = await axiosInstance.put(`/${id}`, vehicleData);
  return response.data;
};

// Delete vehicle
const deleteVehicle = async (id) => {
  const response = await axiosInstance.delete(`/${id}`);
  return response.data;
};

// Upload images for a vehicle
const uploadVehicleImages = async (id, formData) => {
  const response = await axiosInstance.post(`/${id}/images`, formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  });
  return response.data;
};

// Get brands for a vehicle type
const getBrands = async (vehicleType) => {
  const response = await axiosInstance.get(`/brands?type=${vehicleType}`);
  return response.data;
};

// Get models for a vehicle brand
const getModels = async (vehicleType, brand) => {
  const response = await axiosInstance.get(`/models?type=${vehicleType}&brand=${brand}`);
  return response.data;
};

export default {
  getAllVehicles,
  getVehicleById,
  searchVehicles,
  createVehicle,
  updateVehicle,
  deleteVehicle,
  getBrands,
  getModels
};
