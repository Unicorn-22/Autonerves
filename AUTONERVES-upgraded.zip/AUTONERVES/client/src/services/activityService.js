import axios from 'axios';
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api' });
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers['x-auth-token'] = token;
  const consent = localStorage.getItem('autonerves_analytics_consent') || 'no';
  config.headers['x-analytics-consent'] = consent;
  if (consent === 'yes') {
    let sid = localStorage.getItem('autonerves_session');
    if (!sid) { sid = globalThis.crypto?.randomUUID?.() || `session-${Date.now()}-${Math.random().toString(36).slice(2)}`; localStorage.setItem('autonerves_session', sid); }
    config.headers['x-session-id'] = sid;
  }
  return config;
});
export const trackActivity = (eventType, data = {}) => {
  if (typeof localStorage === 'undefined' || localStorage.getItem('autonerves_analytics_consent') !== 'yes') return Promise.resolve(null);
  return api.post('/activity/track', { eventType, ...data }).catch(() => null);
};
export const getDashboard = () => api.get('/activity/dashboard').then(r => r.data);
export default { trackActivity, getDashboard };
