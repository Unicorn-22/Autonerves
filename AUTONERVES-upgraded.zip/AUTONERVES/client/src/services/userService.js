// client/src/services/userService.js
import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Create axios instance with auth token
const axiosInstance = axios.create({
  baseURL: API_URL
});

// Add token to requests
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['x-auth-token'] = token;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const createShowroomAdmin = async data => (await axiosInstance.post('/admin/showroom-admins', data)).data;
const updateUserStatus = async (id, isActive) => (await axiosInstance.patch(`/admin/users/${id}/status`, { isActive })).data;

const getAllUsers = async () => {
  const response = await axiosInstance.get('/admin/users');
  return response.data;
};

const getDashboardSummary = async () => (await axiosInstance.get('/admin/dashboard')).data;
const getActivityDashboard = async () => (await axiosInstance.get('/activity/dashboard')).data;

const getAllShowrooms = async () => {
  const response = await axiosInstance.get('/admin/showrooms');
  return response.data;
};

export default {
  createShowroomAdmin,
  updateUserStatus,
  getDashboardSummary,
  getActivityDashboard,
  getAllUsers,
  getAllShowrooms,
};