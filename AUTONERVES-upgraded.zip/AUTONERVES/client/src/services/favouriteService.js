import axios from 'axios';
const api = axios.create({ baseURL: `${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}/favourites` });
api.interceptors.request.use(c => { const token = localStorage.getItem('token'); if (token) c.headers['x-auth-token'] = token; return c; });
export const toggleFavourite = id => api.post(`/${id}/toggle`).then(r => r.data);
export const getFavourites = () => api.get('/').then(r => r.data);
export default { toggleFavourite, getFavourites };
