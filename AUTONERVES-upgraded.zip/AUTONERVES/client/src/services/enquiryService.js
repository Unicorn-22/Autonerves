import axios from 'axios';
const api = axios.create({ baseURL: `${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}/enquiries` });
api.interceptors.request.use(c => { const token = localStorage.getItem('token'); if (token) c.headers['x-auth-token'] = token; return c; });
export const submitEnquiry = data => api.post('/', data).then(r => r.data);
export const getMyEnquiries = () => api.get('/mine').then(r => r.data);
export const getStaffEnquiries = () => api.get('/').then(r => r.data);
export const updateEnquiryStatus = (id,status) => api.patch(`/${id}/status`,{status}).then(r => r.data);
export default { submitEnquiry, getMyEnquiries, getStaffEnquiries, updateEnquiryStatus };
