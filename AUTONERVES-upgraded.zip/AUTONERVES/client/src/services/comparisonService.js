import axios from 'axios';
const api = axios.create({ baseURL: `${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}/comparisons` });
api.interceptors.request.use(c => { const token = localStorage.getItem('token'); if (token) c.headers['x-auth-token'] = token; return c; });
export const getComparison = () => api.get('/').then(r => r.data);
export const saveComparison = cars => api.put('/', { cars }).then(r => r.data);
export default { getComparison, saveComparison };
