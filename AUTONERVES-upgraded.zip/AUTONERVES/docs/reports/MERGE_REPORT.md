# Merge Report

## What the four ZIPs actually were
| ZIP | Contents | Role in merge |
|---|---|---|
| `showroom.zip` | MERN app, newest; includes Admin module + null-safety fixes | **Base** (strict superset of `showroom_1_`) |
| `showroom_1_.zip` | Same app, minus Admin module (`AdminPanel`, `adminRoutes/Controller`, `admin` middleware, `userService`); stray `// Continuing …` lines in JSX | Variant (diffs archived) |
| `project_1_.zip` | Oldest snapshot of the same app (pre `category` filter, light theme, old seed) | Variant (diffs archived, unique data merged) |
| `shadcn-ui_1_.zip` | **Static HTML/CSS/JS page**, dark theme, blue→violet gradient, with own vehicle/showroom dataset and cart | Design reference + dataset merged |

Git: `project_1_`'s HEAD is an ancestor of `showroom`'s HEAD; `showroom_1_` has the same HEAD. The base `.git` is kept, so history of all three is retained.

Note: the "SHADCN" ZIP is a hand-written imitation of the shadcn look, not the shadcn/ui library. I used its **visual language** (palette, gradient, hero, cards, cart) and implemented it with **real shadcn/ui** (Radix + CVA + tailwind-merge) so both goals are met.

## Merged data/code
- **Reference dataset → database seed**: 6 vehicles + 3 showrooms from `data.js` added (`server/data/reference-showroom-data.json`, verbatim). Added model fields: `Vehicle.currency` (INR|USD), `specifications.horsepower`, `Showroom.services`, `Showroom.specialties`. Coordinates for the 3 showrooms were **added by me** (city centres), not in the source.
- **Legacy seed (`project_1_`) → current seed**: admin + buyer users, "Premium Motors" showroom merged. Verbatim copy kept as `server/utils/seedData.legacy.js` (`npm run seed:legacy`, wipes the DB — throwaway DBs only).
- **Cart** (reference feature) ported as `CartContext` + `CartSheet`; per-currency totals. 
- **Restored** `vite.svg`, `react.svg` (only in `project_1_`) and `.env` rule in `client/.gitignore`.

## Bugs found and fixed
1. `Registration.jsx` imported `utils/validation`, file is `Validation.js` → **build failed on Linux/CI**.
2. Seed scripts pre-hashed passwords while `User` pre-save hashes again → **seeded accounts could not log in**.
3. Seed read `MONGO_URI`, `.env` defines `MONGODB_URI`; dotenv path was wrong.
4. `/placeholder-vehicle.jpg` referenced but never existed → inline SVG placeholder.
5. Links to non-existent `/search` route (older variant) — base already used `/vehicles`.

## UI/UX
Tokens in `client/src/index.css` + `tailwind.config.js`; primitives in `client/src/components/ui` (Button, Input, Label, Card, Badge, Sheet, DropdownMenu). **Rewritten with shadcn components:** Navbar, Footer, mobile menu, user menu, Cart, Home hero, listing/detail action buttons. **All other pages (Login, Registration, Listing, Details, Comparison, Locator, Showroom Details/Management, Admin, NHTSA, 404)** were themed by mapping ~500 legacy Tailwind classes to the shadcn tokens plus global form-control styles — consistent look, but their markup is **not** rebuilt from shadcn primitives.

## Not carried over from the reference (judgement calls)
Stats strip, Contact section, vehicle modal (app has full detail page instead), search-box/filter UI, "favorites" (reference only shows a toast; it persists nothing).

## Not shipped
`node_modules` (Windows-built, ~10k files ×3; reproducible from `package-lock.json`), `.vite` cache dirs. Counted in the mapping as reproducible artefacts, not source.
