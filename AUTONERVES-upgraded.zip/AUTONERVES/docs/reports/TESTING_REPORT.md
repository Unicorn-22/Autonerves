> **Note (2026-11-06):** The results below describe the pre-upgrade merged baseline and do not validate the current AUTONERVES enhancement changes. See [UPGRADE_IMPLEMENTATION.md](./UPGRADE_IMPLEMENTATION.md) for the checks actually run after the upgrade.

# Testing Report (what was actually run)

Environment: Node 22, MongoDB (conda-forge build) on localhost, headless Chromium via Playwright.

## Passed
- `npm ci` client + server from lockfiles; **`vite build` succeeds** (after fixing bug #1).
- `node --check` on every server JS file.
- Seed run against real MongoDB: 3 users, 9 showrooms, **50 vehicles** (44 original + 6 reference).
- API: login for admin & dealer (proves hashing fix); `GET /vehicles` (6 USD records with currency/horsepower); `?category=ev` (10); `/showrooms` (9); `/showrooms/nearby` geo query; `/admin/users` → **200 admin / 403 buyer / 401 anonymous**; `/admin/showrooms` (9).
- Browser: Home, Vehicles, Login, Showrooms, Admin pages render; **real login through the UI** as admin; admin panel loads live data; add-to-cart ×2, cart drawer (quantities, per-currency total); mobile drawer menu; no uncaught JS exceptions.
- Source integrity: **313/313 source files** have a byte-identical copy in the final tree.

## Not tested / limitations
- Google OAuth and Google Maps (need your keys/network). Leaflet tiles, Google Fonts, Unsplash images were blocked in the sandbox, so map rendering and the Unica One logo font were not seen.
- Not exercised in browser: registration, comparison flow, showroom create/edit/delete, vehicle detail page, NHTSA page. They are re-themed but I did not click through them; they are most likely to show visual rough edges.
- Screenshots reviewed: Home, Vehicles, Cart, Admin, mobile menu only. Login/Showrooms were rendered but not visually inspected.
- No automated test suite exists in the sources; none added.
- ESLint: 13 findings (11 errors, 2 warnings) — unused vars, hook deps, fast-refresh export style (also standard in shadcn files). Not fixed; none are runtime failures.
- Bundle >500 kB warning (no code-splitting).
