# Conflicts & items needing your decision

| # | Conflict | Resolution | Status |
|---|---|---|---|
| 1 | Mongo collection: base uses `vehicles-finder`, `project_1_` used default `vehicles` | Base kept | **Open** – if you have data in an old `vehicles` collection it will not appear; migrate it |
| 2 | Listing filter query `type` (old) vs `category` (base) | Base kept (superset) | Resolved |
| 3 | `dealer@example.com` password `dealer123` (legacy seed) vs `password123` (base seed) | Base kept | Resolved (legacy value recorded here) |
| 4 | Price currency: reference USD vs app INR | `currency` field; UI formats per record | Resolved |
| 5 | Three visual themes (grey/blue, white + green `#D1FAE5`, dark reference) | Reference wins, as instructed. Old versions archived | Resolved |
| 6 | `showroom_1_` has stray `// Continuing …` text in JSX | Base (clean) kept; originals archived | Resolved |
| 7 | `project_1_/server/.env` has extra commented Google lines | Base `.env` kept; original archived | Resolved |
| 8 | **Secrets**: `.env` files contain what look like a live Google OAuth secret and Maps key | Preserved (zero-loss) but `.env` now git-ignored, `.env.example` added | **Open – rotate these keys** |
| 9 | API URLs hard-coded to `http://localhost:5000` in services | Unchanged (pre-existing) | Open |
| 10 | Create/update showroom & vehicle forms/controllers do not expose the new optional fields (`services`, `specialties`, `horsepower`, `currency`) | Seed only | Open |
