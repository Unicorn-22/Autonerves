// client/src/components/Navbar.jsx
import { Link, useNavigate } from 'react-router-dom';
import { useState, useContext } from 'react';
import { AuthContext } from '../contexts/AuthContext';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { isAuthenticated, user, logout } = useContext(AuthContext);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-white text-gray-800 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <Link to="/" className="text-2xl md:text-4xl  font-bold unica-one-regular">AUTONERVES</Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-6">

            <Link to="/vehicles" className="hover:text-blue-600 transition">View All Vehicles</Link>
            <Link to="/showrooms" className="hover:text-blue-600 transition">Showroom Locator</Link>
            <Link to="/compare" className="hover:text-blue-600 transition">Compare Vehicles</Link>
          </div>
          
          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <span className="font-medium">Welcome, {user?.name}</span>
                {(user?.role === 'dealer' || user?.role === 'admin') && (
                  <Link to="/manage-showroom" className="hover:text-blue-600 transition">My Showroom</Link>
                )}
                {user?.role === 'admin' && (
                  <Link to="/admin" className="hover:text-blue-600 transition">Admin Panel</Link>
                )}
                <button onClick={handleLogout} className="hover:text-blue-600 transition">Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" className="hover:text-blue-600 transition">Login</Link>
                <Link 
                  to="/register" 
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition"
                >
                  Register
                </Link>
              </>
            )}
          </div>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-3 pb-5">

            <Link to="/vehicles" className="block hover:text-blue-600 transition">View All Vehicles</Link>
            <Link to="/showrooms" className="block hover:text-blue-600 transition">Showroom Locator</Link>
            <Link to="/compare" className="block hover:text-blue-600 transition">Compare Vehicles</Link>
            {isAuthenticated ? (
              <div className="space-y-2 pt-2 border-t border-gray-200">
                <span className="block font-medium">Welcome, {user?.name}</span>
                {(user?.role === 'dealer' || user?.role === 'admin') && (
                  <Link to="/manage-showroom" className="block hover:text-blue-600 transition">My Showroom</Link>
                )}
                {user?.role === 'admin' && (
                  <Link to="/admin" className="block hover:text-blue-600 transition">Admin Panel</Link>
                )}
                <button onClick={handleLogout} className="block w-full text-left hover:text-blue-600 transition">Logout</button>
              </div>
            ) : (
              <div className="space-y-2 pt-2 border-t border-gray-200">
                <Link to="/login" className="block hover:text-blue-600 transition">Login</Link>
                <Link 
                  to="/register" 
                  className="block bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition w-full text-center"
                >
                  Register
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;