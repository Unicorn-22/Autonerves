import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import vehicleService from '../services/vehicleService';
import toast from 'react-hot-toast';
import { getVehicleImage } from '../utils/vehicleImages';
import { useImageSource } from '../contexts/ImageSourceContext';

const VehicleListing = () => {
  const { useDbImages } = useImageSource();
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
  });
  const [searchParams, setSearchParams] = useSearchParams();
  const [filter, setFilter] = useState(searchParams.get('category') || 'all');

  const page = parseInt(searchParams.get('page') || '1');

  useEffect(() => {
    const fetchVehicles = async () => {
      setLoading(true);
      try {
        const params = { 
          page,
          category: filter === 'all' ? '' : filter
        };
        const data = await vehicleService.getAllVehicles(params);
        setVehicles(data.vehicles);
        setPagination({
          currentPage: data.currentPage,
          totalPages: data.totalPages,
        });
      } catch (error) {
        console.error("Error fetching vehicles:", error);
        toast.error("Failed to load vehicles.");
      } finally {
        setLoading(false);
      }
    };

    fetchVehicles();
  }, [page, filter]);

  const handlePageChange = (newPage) => {
    setSearchParams({ page: newPage, category: filter });
  };

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setSearchParams({ page: 1, category: newFilter });
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900">Explore Our Vehicles</h1>
        <p className="mt-3 text-lg text-gray-600">Find the car or bike that best suits you.</p>
      </div>
      
      <div className="flex justify-center mb-10">
        <div className="flex flex-wrap space-x-1 bg-gray-200 p-1 rounded-xl">
          <button 
            onClick={() => handleFilterChange('all')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'all' ? 'bg-white text-blue-600 shadow' : 'text-gray-600 hover:bg-gray-300'}`}>
            All
          </button>
          <button 
            onClick={() => handleFilterChange('car')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'car' ? 'bg-white text-blue-600 shadow' : 'text-gray-600 hover:bg-gray-300'}`}>
            Cars
          </button>
          <button 
            onClick={() => handleFilterChange('bike')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'bike' ? 'bg-white text-blue-600 shadow' : 'text-gray-600 hover:bg-gray-300'}`}>
            Bikes
          </button>
          <button 
            onClick={() => handleFilterChange('ev')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'ev' ? 'bg-white text-blue-600 shadow' : 'text-gray-600 hover:bg-gray-300'}`}>
            EVs
          </button>
          <button 
            onClick={() => handleFilterChange('scooty')} 
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300 ${filter === 'scooty' ? 'bg-white text-blue-600 shadow' : 'text-gray-600 hover:bg-gray-300'}`}>
            Scooters
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-600"></div>
        </div>
      ) : vehicles.length > 0 ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {vehicles.map(vehicle => (
              <div key={vehicle._id} className="bg-white rounded-2xl shadow-md overflow-hidden group transform hover:-translate-y-2 transition-all duration-300 hover:shadow-xl border border-gray-200/80" data-aos="fade-up">
                <div className="h-56 overflow-hidden relative">
                  <img
                    src={useDbImages ? (vehicle.images?.[0] || '/placeholder-vehicle.jpg') : getVehicleImage(vehicle.brand, vehicle.model)}
                    alt={`${vehicle.brand} ${vehicle.model}`}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute top-0 right-0 bg-blue-600 text-white px-3 py-1 text-xs font-bold rounded-bl-xl">
                    {vehicle.category ? vehicle.category.charAt(0).toUpperCase() + vehicle.category.slice(1) : vehicle.type.charAt(0).toUpperCase() + vehicle.type.slice(1)}
                  </div>
                </div>
                <div className="p-5">
                  <h2 className="text-xl font-bold text-gray-800 truncate mb-1">{vehicle.brand} {vehicle.model}</h2>
                  <p className="text-sm text-gray-500 mb-3">{vehicle.year}</p>
                  
                  <div className="flex justify-between items-center mb-4 text-sm">
                      <span className="flex items-center text-gray-600">
                          <svg className="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6V4m0 16v-2m0-10v2m0 6v2m-6-2h2m10 0h2M6 12H4m16 0h-2m-5.414-5.414l-1.414-1.414M18.364 18.364l-1.414-1.414M5.636 5.636l1.414 1.414m11.314 11.314l1.414 1.414"></path></svg>
                          {vehicle.specifications?.fuelType || 'N/A'}
                      </span>
                      <span className="flex items-center text-gray-600">
                          <svg className="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"></path></svg>
                          {vehicle.specifications?.transmission || 'N/A'}
                      </span>
                  </div>

                  <div className="mb-4">
                    <span className="font-bold text-blue-600 text-2xl">₹{vehicle.price.toLocaleString()}</span>
                  </div>
                  <Link
                    to={`/vehicle/${vehicle._id}`}
                    className="block w-full py-2.5 bg-blue-600 text-center text-white font-bold rounded-lg hover:bg-blue-700 transition-all duration-300 shadow-md hover:shadow-lg"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div className="mt-12 flex justify-center items-center space-x-4">
              <button
                onClick={() => handlePageChange(pagination.currentPage - 1)}
                disabled={pagination.currentPage === 1}
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Previous
              </button>
              <span className="text-gray-800 font-medium">
                Page {pagination.currentPage} of {pagination.totalPages}
              </span>
              <button
                onClick={() => handlePageChange(pagination.currentPage + 1)}
                disabled={pagination.currentPage === pagination.totalPages}
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Next
              </button>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-20">
          <h2 className="text-2xl font-semibold text-gray-700">No Vehicles Found</h2>
          <p className="mt-2 text-gray-500">Please try adjusting your filters or check back later.</p>
        </div>
      )}
    </div>
  );
};

export default VehicleListing;