const imageMap = {
  //Bikes Images
  "Royal Enfield Bullet": "/images/vehicles/Royal Enfield Bullet.webp",
  "Royal Enfield Interceptor":
    "/images/vehicles/Royal Enfield Interceptor.webp",
  "Royal Enfield Himalayan": "/images/vehicles/Royal Enfield Himalayan.avif",
  "Bajaj Pulsar": "/images/vehicles/Bajaj Pulsar.avif",
  "Suzuki Burgman Street EX": "/images/vehicles/Suzuki Burgman Street EX.cms",
  "Bajaj Dominar": "/images/vehicles/Bajaj Dominar.avif",
  "Honda Shine": "/images/vehicles/Honda Shine.avif",
  "Bajaj Platina": "/images/vehicles/Bajaj Platina.avif",
  "Hero Passion": "/images/vehicles/Hero Passion.webp",
  "Bajaj Avenger": "/images/vehicles/Bajaj Avenger.webp",
  "Honda Unicorn": "/images/vehicles/Honda Unicorn.webp",
  "Honda Hornet": "/images/vehicles/Honda Hornet.avif",
  "Hero Splendor": "/images/vehicles/Hero Splendor.avif",
  "Hero Vida V1": "/images/vehicles/Hero Vida V1.avif",
  "Royal Enfield Classic 350":
    "/images/vehicles/Royal Enfield Classic 350.avif",
  "Hero Xpulse": "/images/vehicles/Hero Xpulse.jpg",
  "Bajaj Chetak": "/images/vehicles/Bajaj Chetak.jpeg",

  //car Images
  "Maruti Suzuki Baleno": "/images/vehicles/Maruti Suzuki Baleno.jpg",
  "Maruti Suzuki Dzire": "/images/vehicles/Maruti Suzuki Dzire.jpg",
  "Maruti Suzuki Swift": "/images/vehicles/Maruti Suzuki Swift.jpg",
  "Maruti Suzuki Ertiga": "/images/vehicles/Maruti Suzuki Ertiga.jpg",
  "Hyundai i20": "/images/vehicles/Hyundai i20.jpg",
  "Toyota Fortuner": "/images/vehicles/Toyota Fortuner.jpg",
  "Honda CR-V": "/images/vehicles/Honda CR-V.webp",
  "Hyundai i10": "/images/vehicles/Hyundai i10.avif",
  "Hyundai Creta": "/images/vehicles/Hyundai Creta.avif",
  "Honda Accord": "/images/vehicles/Honda Accord.avif",
  "Toyota Corolla": "/images/vehicles/Toyota Corolla.avif",
  "Ather 450X": "/images/vehicles/Ather 450X.avif",
  "Tata Nexon EV": "/images/vehicles/Tata Nexon EV.avif",
  "Ola S1 Pro": "/images/vehicles/Ola S1 Pro.avif",
  "Honda City": "/images/vehicles/Honda City.jpeg",
  "Honda Civic": "/images/vehicles/Honda Civic.webp",
  "MG Comet EV": "/images/vehicles/MG Comet EV.webp",
  "TVS iQube": "/images/vehicles/TVS iQube.webp",
  "Volvo XC40 Recharge": "/images/vehicles/Volvo XC40 Recharge.webp",
  "Kia EV6": "/images/vehicles/Kia EV6.avif",
  "Mercedes-Benz EQS": "/images/vehicles/Mercedes-Benz EQS.avif",
  "Hyundai Tucson": "/images/vehicles/Hyundai Tucson.png",

  "Honda Activa": "/images/vehicles/Honda Activa.png",
  "Mahindra XUV400": "/images/vehicles/Mahindra XUV400.png",
  "Hero Glamour": "/images/vehicles/Hero Glamour.png",
  "Toyota Camry": "/images/vehicles/Toyota Camry.png",
  "Toyota Innova": "/images/vehicles/wp3119881.jpg",
};

const brandDefaults = {
  Toyota: "/images/vehicles/Toyota.svg",
  Mahindra: "/images/desktop-wallpaper-mahindra-thar-thar-car.jpg",
};

export const getVehicleImage = (brand, model) => {
  const key = `${brand} ${model}`;
  if (imageMap[key]) {
    return imageMap[key];
  }
  if (brandDefaults[brand]) {
    return brandDefaults[brand];
  }
  return "/placeholder-vehicle.jpg"; // A generic placeholder
};
