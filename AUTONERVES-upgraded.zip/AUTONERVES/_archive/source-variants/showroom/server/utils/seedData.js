require('dotenv').config({ path: '../.env' });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const Vehicle = require('../models/Vehicle');
const Showroom = require('../models/Showroom');
const User = require('../models/User');

// Image map from client/src/utils/vehicleImages.js
const imageMap = {
  //Bikes Images
  "Royal Enfield Bullet": "/images/vehicles/Royal Enfield Bullet.webp",
  "Royal Enfield Interceptor": "/images/vehicles/Royal Enfield Interceptor.webp",
  "Royal Enfield Himalayan": "/images/vehicles/Royal Enfield Himalayan.avif",
  "Bajaj Pulsar": "/images/vehicles/Bajaj Pulsar.avif",
  "Suzuki Burgman Street EX": "/images/vehicles/Suzuki Burgman Street EX.cms",
  "Bajaj Dominar": "/images/vehicles/Bajaj Dominar.avif",
  "Honda Shine": "/images/vehicles/Honda Shine.avif",
  "Bajaj Platina": "/images/vehicles/Bajaj Platina.avif",
  "Hero Passion": "/images/vehicles/Hero Passion.webp",
  "Bajaj Avenger": "/images/vehicles/Bajaj Avenger.webp",
  "Honda Unicorn": "/images/vehicles/Honda Unicorn.webp",
  "Honda Hornet": "/images/vehicles/Honda Hornet.avif",
  "Hero Splendor": "/images/vehicles/Hero Splendor.avif",
  "Hero Vida V1": "/images/vehicles/Hero Vida V1.avif",
  "Royal Enfield Classic 350": "/images/vehicles/Royal Enfield Classic 350.avif",
  "Hero Xpulse": "/images/vehicles/Hero Xpulse.jpg",
  "Bajaj Chetak": "/images/vehicles/Bajaj Chetak.jpeg",

  //car Images
  "Maruti Suzuki Baleno": "/images/vehicles/Maruti Suzuki Baleno.jpg",
  "Maruti Suzuki Dzire": "/images/vehicles/Maruti Suzuki Dzire.jpg",
  "Maruti Suzuki Swift": "/images/vehicles/Maruti Suzuki Swift.jpg",
  "Maruti Suzuki Ertiga": "/images/vehicles/Maruti Suzuki Ertiga.jpg",
  "Hyundai i20": "/images/vehicles/Hyundai i20.jpg",
  "Toyota Fortuner": "/images/vehicles/Toyota Fortuner.jpg",
  "Honda CR-V": "/images/vehicles/Honda CR-V.webp",
  "Hyundai i10": "/images/vehicles/Hyundai i10.avif",
  "Hyundai Creta": "/images/vehicles/Hyundai Creta.avif",
  "Honda Accord": "/images/vehicles/Honda Accord.avif",
  "Toyota Corolla": "/images/vehicles/Toyota Corolla.avif",
  "Ather 450X": "/images/vehicles/Ather 450X.avif",
  "Tata Nexon EV": "/images/vehicles/Tata Nexon EV.avif",
  "Ola S1 Pro": "/images/vehicles/Ola S1 Pro.avif",
  "Honda City": "/images/vehicles/Honda City.jpeg",
  "Honda Civic": "/images/vehicles/Honda Civic.webp",
  "MG Comet EV": "/images/vehicles/MG Comet EV.webp",
  "TVS iQube": "/images/vehicles/TVS iQube.webp",
  "Volvo XC40 Recharge": "/images/vehicles/Volvo XC40 Recharge.webp",
  "Kia EV6": "/images/vehicles/Kia EV6.avif",
  "Mercedes-Benz EQS": "/images/vehicles/Mercedes-Benz EQS.avif",
  "Hyundai Tucson": "/images/vehicles/Hyundai Tucson.png",

  "Honda Activa": "/images/vehicles/Honda Activa.png",
  "Mahindra XUV400": "/images/vehicles/Mahindra XUV400.png",
  "Hero Glamour": "/images/vehicles/Hero Glamour.png",
  "Toyota Camry": "/images/vehicles/Toyota Camry.png",
  "Toyota Innova": "/images/vehicles/wp3119881.jpg",
};

// Connect to DB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('MongoDB Connected...');
  } catch (err) {
    console.error(err.message);
    process.exit(1);
  }
};

// Helper functions for random data
const getRandomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const getRandomPrice = (type) => {
  if (type === 'car') {
    return getRandomInt(500000, 2000000);
  } else if (type === 'bike') {
    return getRandomInt(80000, 250000);
  } else if (type === 'ev' || type === 'scooty') {
    return getRandomInt(70000, 150000);
  }
  return getRandomInt(100000, 1000000); // Default
};

const getRandomYear = () => getRandomInt(2018, 2023);

const seedVehicles = async () => {
  await connectDB();

  try {
    // Find or Create a Dealer User
    let dealerUser = await User.findOne({ email: 'dealer@example.com' });
    if (!dealerUser) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash('password123', salt);
      dealerUser = new User({
        name: 'Dealer User',
        email: 'dealer@example.com',
        password: hashedPassword,
        role: 'dealer',
        phone: '1234567890'
      });
      await dealerUser.save();
      console.log('Dummy Dealer User created.');
    }

    // Sample Showroom Data
    const sampleShowrooms = [
      {
        name: 'Grand Auto Plaza',
        address: '123 Main St',
        city: 'Metropolis',
        state: 'State',
        location: { type: 'Point', coordinates: [77.5946, 12.9716] }, // Bangalore
        phone: '9876543210',
        email: 'grand.auto@example.com',
        vehicleTypes: ['car', 'bike'],
        description: 'Your one-stop shop for all premium vehicles.',
        photos: ['/images/showrooms/grand_auto_plaza.jpg'],
        hours: '9:00 AM - 8:00 PM'
      },
      {
        name: 'Speed Motors',
        address: '456 Oak Ave',
        city: 'Metropolis',
        state: 'State',
        location: { type: 'Point', coordinates: [77.6046, 12.9816] }, // Near Bangalore
        phone: '9123456780',
        email: 'speed.motors@example.com',
        vehicleTypes: ['car'],
        description: 'Specializing in high-performance cars.',
        photos: ['/images/showrooms/speed_motors.jpg'],
        hours: '10:00 AM - 7:00 PM'
      },
      {
        name: 'Bike World',
        address: '789 Pine Ln',
        city: 'Metropolis',
        state: 'State',
        location: { type: 'Point', coordinates: [77.5846, 12.9616] }, // Near Bangalore
        phone: '9988776655',
        email: 'bike.world@example.com',
        vehicleTypes: ['bike'],
        description: 'The largest collection of bikes in the city.',
        photos: ['/images/showrooms/bike_world.jpg'],
        hours: '9:30 AM - 7:30 PM'
      },
      {
        name: 'Electric Wheels Hub',
        address: '101 Eco Blvd',
        city: 'Metropolis',
        state: 'State',
        location: { type: 'Point', coordinates: [77.6146, 12.9750] }, // Near Bangalore
        phone: '8765432109',
        email: 'ev.hub@example.com',
        vehicleTypes: ['car', 'bike'],
        description: 'Future of mobility, electric vehicles for everyone.',
        photos: ['/images/showrooms/ev_hub.jpg'],
        hours: '10:00 AM - 6:00 PM'
      },
      {
        name: 'New Dummy Showroom',
        address: '789 Test Road',
        city: 'Testville',
        state: 'TestState',
        location: { type: 'Point', coordinates: [77.5946 + 0.001, 12.9716 + 0.001] },
        phone: '9998887770',
        email: 'dummy.showroom@example.com',
        vehicleTypes: ['car', 'bike'],
        description: 'A newly added dummy showroom for testing purposes.',
        photos: ['/images/showrooms/dummy_showroom.jpg'],
        hours: 'Mon-Sat 9 AM - 9 PM'
      }
    ];

    // Create or update Showrooms
    const showrooms = [];
    for (const showroomData of sampleShowrooms) {
      let showroom = await Showroom.findOneAndUpdate(
        { name: showroomData.name },
        { ...showroomData, owner: dealerUser._id },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
      showrooms.push(showroom);
      console.log(`Showroom "${showroom.name}" created or updated.`);
    }

    if (showrooms.length === 0) {
      console.error('No showrooms were created. Exiting seed process.');
      process.exit(1);
    }

    // Clear existing vehicles in 'vehicles-finder' collection
    await Vehicle.deleteMany({});
    console.log('Existing vehicles in vehicles-finder collection cleared.');

    const vehiclesData = [];
    for (const key in imageMap) {
      if (imageMap.hasOwnProperty(key)) {
        const [brand, ...modelParts] = key.split(' ');
        const model = modelParts.join(' ');
        const imagePath = imageMap[key];

        let type = 'car';
        let category = 'sedan'; // Default category for cars

        // Determine type and category based on brand/model
        const bikeBrands = ['Royal Enfield', 'Bajaj', 'Suzuki', 'Honda', 'Hero'];
        const evBrands = ['Ather', 'Tata', 'Ola', 'MG', 'TVS', 'Volvo', 'Kia', 'Mercedes-Benz', 'Mahindra'];
        const scootyModels = ['Chetak', 'Activa', 'S1 Pro', 'iQube', 'Vida V1', 'Burgman Street EX'];

        if (bikeBrands.includes(brand)) {
          type = 'bike';
          category = 'motorcycle';
        }
        if (evBrands.includes(brand) || key.includes('EV') || key.includes('Recharge') || key.includes('S1 Pro') || key.includes('iQube') || key.includes('Vida V1')) {
            type = 'car'; // EVs can be cars or bikes, defaulting to car for now
            category = 'ev';
        }
        if (scootyModels.some(scootyModel => key.includes(scootyModel))) {
            type = 'bike'; // Scooty is a type of bike
            category = 'scooty';
        }
        // Special handling for specific models that might override brand-based type
        if (key.includes('Ather 450X') || key.includes('Ola S1 Pro') || key.includes('TVS iQube') || key.includes('Hero Vida V1')) {
            type = 'bike';
            category = 'ev'; // These are electric bikes/scooters
        }
        if (key.includes('Bajaj Chetak')) {
            type = 'bike';
            category = 'scooty';
        }
        if (key.includes('Mahindra XUV400')) {
            type = 'car';
            category = 'ev';
        }
        if (key.includes('Suzuki Burgman Street EX')) {
            type = 'bike';
            category = 'scooty';
        }


        // Assign a random showroom that matches the vehicle type
        const availableShowrooms = showrooms.filter(sr => sr.vehicleTypes.includes(type));
        const randomShowroom = availableShowrooms[getRandomInt(0, availableShowrooms.length - 1)];

        if (!randomShowroom) {
          console.warn(`No suitable showroom found for ${brand} ${model} (type: ${type}). Skipping.`);
          continue;
        }

        vehiclesData.push({
          type,
          brand,
          model,
          category,
          year: getRandomYear(),
          price: getRandomPrice(type),
          showroom: randomShowroom._id,
          images: [imagePath],
          description: `Experience the thrill of the ${brand} ${model}. A perfect blend of style and performance.`,
          specifications: {
            engine: type === 'car' ? '1.5L' : '200cc',
            transmission: getRandomInt(0, 1) === 0 ? 'Manual' : 'Automatic',
            mileage: type === 'car' ? '15 kmpl' : '40 kmpl',
            fuelType: category === 'ev' ? 'Electric' : (type === 'car' ? 'Petrol' : 'Petrol'),
            seatingCapacity: type === 'car' ? getRandomInt(4, 7) : 2,
            colors: ['Red', 'Blue', 'Black', 'White'],
            features: ['ABS', 'Touchscreen', 'Navigation']
          },
          available: true,
        });
      }
    }

    await Vehicle.insertMany(vehiclesData);
    console.log('Vehicles seeded successfully!');
  } catch (error) {
    console.error('Error seeding vehicles:', error.message);
    process.exit(1);
  } finally {
    mongoose.connection.close();
  }
};

seedVehicles();